document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("button");
    const slideDownElements = document.querySelectorAll(".slide-down");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("button2");
    const slideDownElements = document.querySelectorAll(".slide-down2");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  
  
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("button3");
    const slideDownElements = document.querySelectorAll(".slide-down3");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("button4");
    const slideDownElements = document.querySelectorAll(".slide-down4");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("button5");
    const slideDownElements = document.querySelectorAll(".slide-down5");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("button6");
    const slideDownElements = document.querySelectorAll(".slide-down6");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("button7");
    const slideDownElements = document.querySelectorAll(".slide-down7");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("button8");
    const slideDownElements = document.querySelectorAll(".slide-down8");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("nav-icon");
    const slideDownElements = document.querySelectorAll(".nav-mobile");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile1");
    const slideDownElements = document.querySelectorAll(".slide-mobile1");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile2");
    const slideDownElements = document.querySelectorAll(".slide-mobile2");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile3");
    const slideDownElements = document.querySelectorAll(".slide-mobile3");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile4");
    const slideDownElements = document.querySelectorAll(".slide-mobile4");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile5");
    const slideDownElements = document.querySelectorAll(".slide-mobile5");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile6");
    const slideDownElements = document.querySelectorAll(".slide-mobile6");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile7");
    const slideDownElements = document.querySelectorAll(".slide-mobile7");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile8");
    const slideDownElements = document.querySelectorAll(".slide-mobile8");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile9");
    const slideDownElements = document.querySelectorAll(".slide-mobile9");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile10");
    const slideDownElements = document.querySelectorAll(".slide-mobile10");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile11");
    const slideDownElements = document.querySelectorAll(".slide-mobile11");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });
  document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("footer-mobile12");
    const slideDownElements = document.querySelectorAll(".slide-mobile12");
  
    button.addEventListener("click", function() {
   slideDownElements.forEach(function(element) {
     if (element.style.display === "none") {
       element.style.display = "block";
     } else {
       element.style.display = "none";
     }
      });
  });
  });