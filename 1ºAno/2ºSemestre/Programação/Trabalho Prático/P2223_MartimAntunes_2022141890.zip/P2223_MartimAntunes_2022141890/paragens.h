

#ifndef P2223_MARTIMANTUNES_2022141890_PARAGENS_H
#define P2223_MARTIMANTUNES_2022141890_PARAGENS_H

#include "linhas.h"

typedef struct paragem pr,*ppr;
struct paragem{
    char nome[100];
    char codigo[5];
    ppr prox;

};

ppr adiciona_paragem(ppr tab,int *total);
ppr elimina_paragem(ppr tab,plinha p ,int *total);
void visualiza_paragens(ppr tab, int *total);




#endif //P2223_MARTIMANTUNES_2022141890_PARAGENS_H
