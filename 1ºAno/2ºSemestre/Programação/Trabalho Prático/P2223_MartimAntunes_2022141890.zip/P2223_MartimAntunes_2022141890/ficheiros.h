
#include "paragens.h"
#include "linhas.h"
#ifndef P2223_MARTIMANTUNES_2022141890_FICHEIROS_H
#define P2223_MARTIMANTUNES_2022141890_FICHEIROS_H
void guardaparagens(pr *b,int total);
ppr leDados(int *total);
int guardaLista(plinha p, char *nomeF);
plinha insereNoFinal(plinha lista, plinha novaLinha);
plinha recuperaLista(char *nomeF);
plinha leTXT(char *nomeFicheiro,plinha p,ppr paragens,int *total);
#endif //P2223_MARTIMANTUNES_2022141890_FICHEIROS_H
