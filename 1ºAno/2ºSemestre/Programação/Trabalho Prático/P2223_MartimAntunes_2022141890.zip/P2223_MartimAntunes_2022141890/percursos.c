
//Martim Alexandre Vieira Antunes  2022141890
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "linhas.h"
#include "paragens.h"
#include "percursos.h"


void exibir_percursos(ppr partida, ppr chegada) {
    ppr paragem = partida;
    int exibir = 1;  // Definir exibir como 1 no início
    printf("Percurso:\n");

    while (paragem != NULL) {
        if (exibir) {
            printf("%s\n", paragem->nome);
        }
        if (paragem == partida) {
            exibir = 0;  // Definir exibir como 0 após exibir a paragem de partida
        }
        if (paragem == chegada) {
            exibir = 1;  // Definir exibir como 1 para exibir a paragem de chegada e as subsequentes
        }
        paragem = paragem->prox;
    }
}
void calcula_percursos(plinha p) {
    plinha linha_partida = NULL;
    plinha linha_chegada = NULL;
    char partida[50], chegada[50];

    printf("Ponto de partida: ");
    scanf(" %[^\n]", partida);

    printf("Ponto de chegada: ");
    scanf(" %[^\n]", chegada);
    // Encontrar as linhas que contêm a paragem de partida e a paragem de chegada
    while (p != NULL) {
        ppr aux = p->lista;
        while (aux != NULL) {
            if (strcmp(aux->nome, partida) == 0) {
                linha_partida = p;
            }
            if (strcmp(aux->nome, chegada) == 0) {
                linha_chegada = p;
            }
            aux = aux->prox;
        }
        p = p->prox;
    }

    // Verificar se as paragens de partida e chegada foram encontradas
    if (linha_partida == NULL || linha_chegada == NULL) {
        printf("As paragens de partida ou chegada nao foram encontradas.\n");
        return;
    }

    // Verificar se o percurso é feito numa única linha
    if (linha_partida == linha_chegada) {
        printf("Percurso efetuado numa unica linha: %s\n", linha_partida->nome);
        exibir_percursos(linha_partida->lista, linha_chegada->lista);

    }




    // Verificar se há um transbordo entre as linhas
    plinha linha_transbordo = NULL;
    plinha aux_partida = linha_partida->prox;

    plinha linha_atual = linha_partida;
    while (linha_atual != NULL) {         //Percorrer a linha onde esta a paragem de partida
        ppr paragem_atual = linha_atual->lista;
        while (paragem_atual != NULL) {             //Percorrer todas as paragens da linha partida
            plinha linha_destino = linha_chegada->prox;
            while (linha_destino != NULL) {                 //Percorrer a linha onde esta a paragem de destino
                ppr paragem_destino = linha_destino->lista;
                while (paragem_destino != NULL) {
                    if (strcmp(paragem_atual->nome, paragem_destino->nome) == 0) { //SE exitir em 2 linhas paragens iguais
                        linha_transbordo = linha_atual;
                        break;
                    }
                    paragem_destino = paragem_destino->prox;
                }
                if (linha_transbordo != NULL) {
                    break;
                }
                linha_destino = linha_destino->prox;
            }

            paragem_atual = paragem_atual->prox;
        }
        if (linha_transbordo != NULL) {
            break;
        }
        linha_atual = linha_atual->prox;
    }

    // Exibir os resultados
    if (linha_transbordo != NULL) {
        printf("Percurso com um transbordo:\n");
        printf("O passageiro parte na linha %s\n", linha_partida->nome);

        printf("Para chegar ao seu destino tera de mudar para a linha %s\n", linha_chegada->nome);
        printf("Percurso entre a partida e o transbordo\n");
        exibir_percursos(linha_partida->lista, linha_transbordo->lista);

        printf("Percurso entre o transbordo e a chegada\n");
        exibir_percursos(linha_transbordo->lista, linha_chegada->lista);

    } else {
        printf("Nao foi possivel encontrar um percurso com um transbordo.\n");
    }
}