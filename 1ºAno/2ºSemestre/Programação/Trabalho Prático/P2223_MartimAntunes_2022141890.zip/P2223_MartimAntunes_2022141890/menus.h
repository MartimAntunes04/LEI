//
// Created by ASUS on 11/06/2023.
//

#ifndef P2223_MARTIMANTUNES_2022141890_MENUS_H
#define P2223_MARTIMANTUNES_2022141890_MENUS_H
void menu_principal();
void menu_paragens();
void menu_linhas();
void submenu_linhas();
void menu_percursos();
#endif //P2223_MARTIMANTUNES_2022141890_MENUS_H
