
//Martim Alexandre Vieira Antunes  2022141890
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "paragens.h"
#include "linhas.h"

char *codigo_alfanumerico(int length) {
    char *codigo,*caracteres;
    int indice,i;

    srand(time(NULL)); // somente para gerar números aleatórios
    codigo = malloc((length + 1) * sizeof(char)); // aloca espaço para o código e para o caractere nulo final
    caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (i = 0; i < length; i++) {
        indice = rand() % 62; // escolhe um índice aleatório no charset
        codigo[i] = caracteres[indice];
    }
    codigo[length] = '\0'; // adiciona o caractere nulo final
    return codigo;
}



ppr adiciona_paragem(ppr tab,int *total){
    ppr aux;
    char *code= codigo_alfanumerico(4);

    aux=realloc(tab,sizeof(pr)*(*total+1));
    if(aux!=NULL){
        tab=aux;
        printf("\nDados da nova paragem");
        printf("\nNome: ");
        scanf(" %[^\n]",tab[*total].nome);
        strcpy(tab[*total].codigo,code);
        printf("Codigo: %s\n", tab[*total].codigo);

        (*total)++;
    }
    return tab;
}

void visualiza_paragens(ppr tab, int *total) {
    int i;
    printf("\nLista de paragens\n");
    for (i = 0; i < *total; i++) {
        printf("Nome:%s\n", tab[i].nome);
        printf("Codigo:%s\n", tab[i].codigo);
        printf("\n");
    }
}


ppr elimina_paragem(ppr tab, plinha p, int *total) {
    pr *aux, t;
    int i, j;
    char elimina[100];
    int pertence_linha = 0;

    printf("\nCodigo da paragem que pretende eliminar: ");
    scanf("%s", elimina);

    // Verificar se a paragem pertence a alguma linha
    for (j = 0; j < p->total; j++) {
        ppr aux_linha = p->lista;
        while (aux_linha != NULL) {
            if (strcmp(aux_linha->codigo, elimina) == 0) {
                pertence_linha = 1;
                break;
            }
            aux_linha = aux_linha->prox;
        }
        if (pertence_linha) {
            printf("A paragem pertence a uma linha e nao pode ser eliminada.\n");
            return tab;
        }
    }

    for (i = 0; i < *total; i++) {
        if (strcmp(elimina, tab[i].codigo) == 0) {
            printf("Paragem eliminada\n");
            break;
        }
    }

    if (i == *total) {
        printf("Paragem nao existe no sistema\n");
        return tab;
    } else if (*total == 1) {
        free(tab);
        *total = 0;
        return NULL;
    } else {
        // Eliminar a paragem
        t = tab[i];
        tab[i] = tab[*total - 1];
        aux = realloc(tab, sizeof(pr) * (*total - 1));

        if (aux != NULL) {
            tab = aux;
            (*total)--;
        } else {
            tab[i] = t;
        }

        return tab;
    }
}