

#ifndef P2223_MARTIMANTUNES_2022141890_PERCURSOS_H
#define P2223_MARTIMANTUNES_2022141890_PERCURSOS_H
void exibir_percursos(ppr partida,ppr chegada);
void calcula_percursos(plinha p);
int mesmo_percurso(ppr lista1, ppr lista2);
#endif //P2223_MARTIMANTUNES_2022141890_PERCURSOS_H
