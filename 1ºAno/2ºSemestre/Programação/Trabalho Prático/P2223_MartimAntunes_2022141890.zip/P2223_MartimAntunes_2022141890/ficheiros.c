

//Martim Alexandre Vieira Antunes  2022141890
#include <stdio.h>
#include <stdlib.h>
#include "ficheiros.h"


#include <string.h>
//Array Dinamico
void guardaparagens(ppr b,int total){
    FILE *f;

    f = fopen("paragens.bin","wb");
    if(f==NULL){
        printf("Erro no acesso ao ficheiro\n");
        return;
    }
    fwrite(&total,sizeof(int),1,f);
    fwrite(b,sizeof(pr),total,f);
    fclose(f);
}

ppr leDados(int *total){
    FILE *f;
    pr *b=NULL;
    *total=0;

    f= fopen("paragens.bin","rb");
    if(f==NULL){
        printf("Erro no acesso ao ficheiro\n");
        return NULL;
    }
    fread(total,sizeof(int),1,f);
    b=malloc(sizeof (pr)*(*total));
    if(b==NULL){
        fclose(f);
        *total=0;
        return NULL;
    }
    fread(b,sizeof(pr),*total,f);
    fclose(f);
    return b;
}


//Lista Ligada

int guardaLista(plinha p, char *nomeF){
    FILE *f;

    f=fopen(nomeF,"wb");
    if(f==NULL){
        return -1;
    }
    while(p!=NULL){
        fwrite(p,sizeof(linha),1,f);
        ppr paragem=p->lista;
        while(paragem!=NULL){
            fwrite(paragem,sizeof(pr),1,f);
            paragem=paragem->prox;

        }
        p=p->prox;
    }
    fclose(f);
    return 1;
}

plinha insereNoFinal(plinha lista, plinha novaLinha) {
    if (lista == NULL) {
        return novaLinha;
    }

    plinha atual = lista;
    while (atual->prox != NULL) {
        atual = atual->prox;
    }

    atual->prox = novaLinha;
    return lista;
}


plinha recuperaLista(char *nomeF){
    plinha novo,p=NULL;
    linha lin;
    FILE *f;

    f= fopen(nomeF,"rb");
    if(f==NULL)
        return NULL;
    while(fread(&lin,sizeof(linha),1,f)==1){
        novo= malloc(sizeof(linha));
        if(novo==NULL){
            fclose(f);
            return p;
        }
        *novo = lin;
        novo->prox = NULL;
        novo->lista=NULL;
        p=insereNoFinal(p,novo);
        for (int i = 0; i < lin.total; i++) {
            ppr nova_paragem = malloc(sizeof(pr));
            if (nova_paragem == NULL) {
                fclose(f);
                return p;
            }
            fread(nova_paragem, sizeof(pr), 1, f);
            nova_paragem->prox = NULL;

            if (novo->lista == NULL) {
                novo->lista = nova_paragem;
            } else {
                ppr aux = novo->lista;
                while (aux->prox != NULL) {
                    aux = aux->prox;
                }
                aux->prox = nova_paragem;
            }
        }
    }
    fclose(f);
    return p;
}

plinha leTXT(char *nomeFicheiro, plinha p, ppr paragens, int *total) {
    FILE *f;
    ppr nova_paragem;
    char nome_linha[100];
    char nome_paragem[100];
    char codigo_paragem[100];
    plinha linha_encontrada = NULL;
    int todas_paragens_registadas = 1;

    f = fopen(nomeFicheiro, "r");
    if (f == NULL) {
        printf("Erro no acesso ao ficheiro\n");
        return NULL;
    }

    fgets(nome_linha, sizeof(nome_linha), f);

    plinha atual = p;
    while (atual != NULL) {
        if (strcmp(atual->nome, nome_linha) == 0) {
            printf("Ja existe uma linha com este nome.\n");
            fclose(f);
            return NULL;
        }
        atual = atual->prox;
    }

    plinha novo = malloc(sizeof(linha));
    if (novo == NULL) {
        printf("Erro ao alocar memória para a nova linha.\n");
        fclose(f);
        return NULL;
    }

    strcpy(novo->nome, nome_linha);
    novo->lista = NULL;
    novo->total = 0;
    novo->prox = p;
    linha_encontrada = novo;

    while (fscanf(f, "%[^#]#%s", nome_paragem, codigo_paragem) == 2) {
        int paragem_existente = 0;
        for (int j = 0; j < *total; j++) {
            if (strcmp(paragens[j].codigo, codigo_paragem) == 0) {
                paragem_existente = 1;
                break;
            }
        }

        if (!paragem_existente) {
            todas_paragens_registadas = 0;
            printf("A paragem %s nao esta registada no sistema.A linha nao sera criada\n", nome_paragem);
            fclose(f);
            return NULL;
        } else {
            nova_paragem = malloc(sizeof(pr));
            if (nova_paragem == NULL) {
                printf("Erro ao alocar memória para a nova paragem..\n");
                fclose(f);
                return NULL;
            }
            strcpy(nova_paragem->nome, nome_paragem);
            strcpy(nova_paragem->codigo, codigo_paragem);
            nova_paragem->prox = NULL;

            if (linha_encontrada->lista == NULL) {
                linha_encontrada->lista = nova_paragem;
            } else {
                ppr aux = linha_encontrada->lista;
                while (aux->prox != NULL) {
                    aux = aux->prox;
                }
                aux->prox = nova_paragem;
            }

            linha_encontrada->total++;
        }
    }

    printf("Linha e paragens adicionadas com sucesso.\n");

    fclose(f);

    return novo;
}