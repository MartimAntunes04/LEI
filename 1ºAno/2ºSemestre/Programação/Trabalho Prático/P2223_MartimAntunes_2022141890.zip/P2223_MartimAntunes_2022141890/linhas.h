
//Martim Alexandre Vieira Antunes  2022141890
typedef struct paragem pr,*ppr;
#ifndef P2223_MARTIMANTUNES_2022141890_LINHAS_H
#define P2223_MARTIMANTUNES_2022141890_LINHAS_H


typedef struct line linha,*plinha;
struct line{
    char nome[50];
    int total;
    ppr lista;
    plinha prox;
};

plinha cria_linha(plinha p);
void adic_paragem(plinha p, char* nome_linha, ppr paragens, int *total);
void elim_paragem(plinha p,char *nome_linha,ppr paragens,int *total);
void escreve_tudo(plinha p);

void atualizar_linha(plinha p, ppr paragens, int *total);
void escreve_linhas_de_paragem(plinha p);

#endif //P2223_MARTIMANTUNES_2022141890_LINHAS_H
