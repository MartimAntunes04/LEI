
//Martim Alexandre Vieira Antunes  2022141890
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "linhas.h"
#include "paragens.h"


void escreve_tudo(plinha p){

    ppr aux;
    while(p!=NULL){
        printf("%s\t %d Paragens\n",p->nome,p->total);
        aux=p->lista;
        while (aux!=NULL){
            printf("\t%s\t%s\n",aux->nome,aux->codigo);
            aux=aux->prox;
        }
        p=p->prox;
        printf("\n");
    }
}

plinha cria_linha(plinha p) {
    char nome_linha[50];
    plinha novo;

    printf("Nova linha: ");
    scanf(" %[^\n]", nome_linha);

    // Verificar se já existe uma linha com o mesmo nome
    plinha atual = p;
    while (atual != NULL) {
        if (strcmp(atual->nome, nome_linha) == 0) {
            printf("Ja existe uma linha com este nome.\n");
            return p;
        }
        atual = atual->prox;
    }

    // Criar uma nova linha
    novo = malloc(sizeof(linha));
    if (novo == NULL) {
        printf("Erro ao alocar memória para a nova linha.\n");
        return p;
    }

    strcpy(novo->nome, nome_linha);
    novo->lista = NULL;
    novo->total = 0;
    novo->prox = p;

    return novo;
}




//Adicionar uma paragem numa linha existente
void adic_paragem(plinha p, char* nome_linha, ppr paragens, int *total) {
    ppr nova_paragem;
    char nome_paragem[100];
    char codigo_paragem[100];
    int num_paragens;
    plinha linha_encontrada = NULL;
    while (p != NULL) {
        if (strcmp(p->nome, nome_linha) == 0) {
            linha_encontrada = p;
            break;
        }
        p = p->prox;
    }

    if (linha_encontrada == NULL) {
        printf("Linha nao encontrada no sistema.\n");
        return;
    }
    printf("Numero de paragens que pretende adicionar nesta linha: ");
    scanf("%d", &num_paragens);



    for (int i = 0; i < num_paragens; i++) {
        printf("Nome da paragem que pretende adicionar: ");
        scanf(" %[^\n]", nome_paragem);
        printf("Codigo da paragem: ");
        scanf("%s",codigo_paragem);

        int paragem_existente = 0;
        for (int j = 0; j < *total; j++) {
            if (strcmp(paragens[j].codigo, codigo_paragem) == 0) {
                paragem_existente = 1;
                break;
            }
        }

        if (!paragem_existente) {
            printf("Nao e possivel incluir na linha, paragens nao registadas no sistema.\n");
        } else {
            nova_paragem = malloc(sizeof(pr));
            if (nova_paragem == NULL) {
                printf("Erro ao alocar memoria para a nova paragem.\n");
                return;
            }

            strcpy(nova_paragem->nome, nome_paragem);
            strcpy(nova_paragem->codigo,codigo_paragem);
            nova_paragem->prox = NULL;

            if (linha_encontrada->lista == NULL) {        //se a lista estiver vazia
                linha_encontrada->lista = nova_paragem;   //esta é a primeira
            } else {                                      //senao
                ppr aux = linha_encontrada->lista;
                while (aux->prox != NULL) {
                    aux = aux->prox;                     //percorre todas as paragens ate encontrar a ultima
                }
                aux->prox = nova_paragem;
            }

            linha_encontrada->total++;
            printf("A paragem foi adicionada com sucesso.\n");
        }
    }
}



void elim_paragem(plinha p, char* nome_linha, ppr paragens, int* total) {
    char elimina[100];
    int num_paragens;
    ppr atual, ant;

    printf("Numero de paragens que pretende eliminar nesta linha: ");
    scanf("%d", &num_paragens);

    plinha linha_encontrada = NULL;
    while (p != NULL) {
        if (strcmp(p->nome, nome_linha) == 0) {
            linha_encontrada = p;
            break;
        }
        p = p->prox;
    }

    if (linha_encontrada == NULL) {
        printf("Linha nao encontrada no sistema.\n");
        return;
    }

    for (int i = 0; i < num_paragens; i++) {
        printf("Nome da paragem que pretende eliminar: ");
        scanf(" %[^\n]", elimina);

        int paragem_encontrada = 0;
        atual = linha_encontrada->lista;
        ant = NULL;

        while (atual != NULL) {
            if (strcmp(atual->nome, elimina) == 0) {
                paragem_encontrada = 1;
                break;
            }
            ant = atual;
            atual = atual->prox;
        }

        if (paragem_encontrada) {
            printf("Paragem eliminada\n");

            // Remover a paragem da lista ligada
            if (ant == NULL) {
                linha_encontrada->lista = atual->prox;
            } else {
                ant->prox = atual->prox;
            }

            linha_encontrada->total--;
            free(atual);



        } else {
            printf("Paragem nao existe nesta linha.\n");
        }
    }
}

void atualizar_linha(plinha p, ppr paragens, int *total) {
    char nome_linha[50];


    printf("Linha que pretende atualizar: ");
    scanf(" %[^\n]",nome_linha);
    plinha linha_encontrada = NULL;
    while (p != NULL) {
        if (strcmp(p->nome, nome_linha) == 0) {
            linha_encontrada = p;
            break;
        }
        p = p->prox;
    }

    if (linha_encontrada == NULL) {
        printf("Linha nao encontrada no sistema.\n");
        return;
    }

    int escolha;
    printf("1 - Adicionar paragens\n");
    printf("2 - Remover paragens\n");
    printf("Escolha uma opcao: ");
    scanf("%d", &escolha);

    switch (escolha) {
        case 1:

            adic_paragem(p,nome_linha,paragens,total);
            break;
        case 2:

            elim_paragem(p,nome_linha,paragens,total);

            break;
        default:
            printf("Opcao invalida.\n");
            break;
    }
}

void escreve_linhas_de_paragem(plinha p) {
    char paragem_desejada[50];
    ppr aux;
    int paragem_encontrada = 0;

    printf("Paragem que pretende saber em que linhas esta incluida: ");
    scanf(" %[^\n]", paragem_desejada);

    while (p != NULL) {
        aux = p->lista;
        paragem_encontrada = 0; // Reinicializa a variável para cada linha

        while (aux != NULL) {
            if (strcmp(aux->nome, paragem_desejada) == 0) {
                paragem_encontrada = 1;
                break;
            }
            aux = aux->prox;


        }
        if (paragem_encontrada) {
            printf("%s\n", p->nome);
        }


        p = p->prox;
    }


}