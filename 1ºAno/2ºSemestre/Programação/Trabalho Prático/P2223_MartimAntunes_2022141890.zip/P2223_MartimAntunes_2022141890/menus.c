//
// Created by ASUS on 11/06/2023.
//
//Martim Alexandre Vieira Antunes  2022141890
#include <stdio.h>


void menu_principal() {
    printf("Metro Mondego\n");
    printf("Menu Principal\n");
    printf("1. Paragens\n");
    printf("2. Linhas\n");
    printf("3. Percursos\n");
    printf("4.Sair\n");


}

void menu_paragens(){
    printf("Menu Paragens\n");
    printf("1. Adicionar paragem\n");
    printf("2. Eliminar paragem\n");
    printf("3. Visulizar paragens\n");
    printf("4. Voltar\n");
};

void menu_linhas(){
    printf("Menu Linhas\n");
    printf("1.Adicionar linha\n");
    printf("2.Atualizar linha\n");
    printf("3.Procurar paragem\n");
    printf("4.Visulizar as linhas e respetivas paragens\n");
    printf("5.Voltar\n");
}

void submenu_linhas(){
    printf("1.Introduza a informacao da linha\n");
    printf("2.Ler ficheiro de texto\n");
    printf("3.Voltar\n");

}

void menu_percursos(){
    printf("Menu Percursos\n");
    printf("1.Calcule o seu percurso\n");
    printf("2.Voltar\n");
}