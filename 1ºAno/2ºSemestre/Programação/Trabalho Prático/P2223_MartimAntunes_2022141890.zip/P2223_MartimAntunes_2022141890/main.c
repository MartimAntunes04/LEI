//Martim Alexandre Vieira Antunes  2022141890

#include <stdio.h>
#include <string.h>
#include "paragens.h"
#include "linhas.h"
#include <stdlib.h>
#include "menus.h"
#include "ficheiros.h"
#include "percursos.h"

int main() {

    ppr tab=NULL;
    plinha lista=NULL;
    int total=0,i;
    int opcao_principal;
    int opcao_paragens;
    int opcao_linhas;
    int opcao_crialinha;
    int opcao_percursos;
    char reload[10];



    int opcaoValida = 0;
    while (!opcaoValida) {
        printf("Deseja continuar com as paragens e linhas anteriores? (S/N): ");
        scanf("%s", reload);

        if (strcmp(reload, "S") == 0) {
            tab = leDados(&total);
            lista = recuperaLista("lista.bin");
            opcaoValida = 1;  // Opção válida, sair do loop
        } else if (strcmp(reload, "N") == 0) {
            opcaoValida = 1;  // Opção válida, sair do loop
        } else {
            printf("Opcao invalida. Por favor, selecione uma opcao valida.\n");
        }
    }






    do {
        menu_principal();
        printf("Selecione uma opcao: ");
        scanf("%d", &opcao_principal);

        switch (opcao_principal) {
            case 1:
                do {
                    menu_paragens();
                    printf("Selecione uma opcao: ");
                    scanf("%d", &opcao_paragens);

                    switch (opcao_paragens) {
                        case 1:
                            tab = adiciona_paragem(tab, &total);
                            break;
                        case 2:
                            tab= elimina_paragem(tab,lista,&total);
                            break;
                        case 3:
                            visualiza_paragens(tab,&total);
                            break;
                        case 4:
                            printf("Voltando ao menu principal...\n");
                            break;
                        default:
                            printf("Opção inválida. Por favor, selecione uma opção válida.\n");
                    }
                } while (opcao_paragens != 4);
                break;

            case 2:
                do{
                    menu_linhas();
                    printf("Selecione uma opcao: ");
                    scanf("%d",&opcao_linhas);
                    switch (opcao_linhas) {
                        case 1:
                            do {
                                submenu_linhas();
                                printf("Selecione a opcao que pretende: ");
                                scanf("%d", &opcao_crialinha);
                                switch (opcao_crialinha) {
                                    case 1:
                                        lista = cria_linha(lista);
                                        break;
                                    case 2:
                                        lista = leTXT("Linha Oeste.txt", lista, tab, &total);



                                        break;
                                    case 3:
                                        printf("Voltando ao menu das linhas...\n");
                                        break;
                                    default:
                                        printf("Opcao invalida. Por favor, selecione uma opcao valida.\n");
                                }
                            }while (opcao_crialinha != 3);

                            break;
                        case 2:
                            atualizar_linha(lista,tab,&total);
                            break;
                        case 3:
                            escreve_linhas_de_paragem(lista);
                            break;
                        case 4:
                            escreve_tudo(lista);
                            break;
                        case 5:
                            printf("Voltando ao menu principal...\n");
                            break;
                        default:
                            printf("Opçao invalida. Por favor, selecione uma opcao valida.\n");

                    }

                }while(opcao_linhas!=5);
                break;

            case 3:
                do{
                    menu_percursos();
                    printf("Selecione uma opcao: ");
                    scanf("%d",&opcao_percursos);
                    switch (opcao_percursos){
                        case 1:
                            calcula_percursos(lista);
                            break;
                        case 2:
                            printf("Voltando ao menu principal...\n");
                            break;
                        default:
                            printf("Opção inválida. Por favor, selecione uma opção válida.\n");
                    }
                }while(opcao_percursos!=2);
                break;

            case 4:
                printf("Encerrando o programa...\n");
                break;
            default:
                printf("Opção inválida. Por favor, selecione uma opção válida.\n");
        }
    } while (opcao_principal != 4);

    guardaparagens(tab,total);
    guardaLista(lista,"lista.bin");


    free(tab);
    free(lista);

    return 0;

}
