import React from "react";
import "./control-panel.css"

function ControlPanel(props){
    const { gameStarted, selectedLevel, onGameStart, onLevelChange,timerX,timerO,onNick1Change, onNick2Change, isNickValid,player1Symbol,player2Symbol,nick1,nick2} = props;
  const gameStartedClass = gameStarted ? " gameStarted" : "";
 
    return(
        <section id="panel-control">
      <h3 className="sr-only">Escolha do Nível</h3>
      <form className="form">
        <fieldset className="form-group">
          <label htmlFor="btLevel">Nível:</label>
          <select id="btLevel"
           defaultValue={0} 
           onChange={onLevelChange} 
           disabled={gameStarted}
           >
            
            <option value="0">Seleccione...</option>
            <option value="1">Um Jogador</option>
            <option value="2">Multijogador</option>
            </select>
        </fieldset>
        
        <button  type="button" id="btPlay"
          disabled={selectedLevel==="0"}
          onClick={onGameStart}
           
    >
            {gameStarted ? 'Terminar Jogo':'Iniciar jogo'}
            
        </button>
        
      </form>


      <div className="formInputs">
                    <label id="jogador1" disabled={gameStarted} className={`${selectedLevel === '1' || selectedLevel === '2' ? "" : "hide"} `}>Jogador 1</label>
                    <input 
                        id="nome1" 
                        type="text" 
                        size="15" 
                        placeholder="Introduzir nome" 
                        className={`${selectedLevel === '1' || selectedLevel === '2' ? "" : "hide"} `} 
                        disabled={gameStarted}
                        onChange={onNick1Change}
                        value={nick1}
                        
                        
                    />
                    <div id="simbolo1" className={`${selectedLevel === '1' || selectedLevel === '2' ? "" : "hide"} `}>Simbolo Jogador 1:  {selectedLevel === '1' ? 'X' : player1Symbol}  </div>
                   
                   
                   <label id="jogador2" disabled={gameStarted} className={` ${selectedLevel === '2' ? "" : "hide"}`}>Jogador 2</label>
                    <input 
                        id="nome2" 
                        type="text" 
                        size="15" 
                        placeholder="Introduzir nome" 
                        className={` ${selectedLevel === '2' ? "" : "hide"}`} 
                        disabled={gameStarted}
                        onChange={onNick2Change}
                        value={nick2}
                    />
                    <div id="simbolo2" className={` ${selectedLevel === '2' ? "" : "hide"}`}>Simbolo Jogador 2:  {player2Symbol}  </div>
                </div>
                
                
                
                
      <div id="alerta" className={`${isNickValid ? "alert alert-danger hide" : "alert alert-danger"}`}>
              <strong>INSIRA NOME!</strong>
            
      </div>


      <div className="form-metadata">
        <p id="message" role="alert" className="left hide">
          Clique em Iniciar o Jogo!
        </p>
        <dl className={`list-item left${gameStartedClass}`}>
          <dt>Tempo de Jogo X: </dt>
          <dd id="gameTime">{timerX}</dd>
          
          <dt>Tempo de Jogo O:</dt>
          {selectedLevel !== "1" && (
          <dd id="gameTime">{timerO}</dd>
          )}
        </dl>
      </div>

      
      
    </section>
    );
}

export default ControlPanel;