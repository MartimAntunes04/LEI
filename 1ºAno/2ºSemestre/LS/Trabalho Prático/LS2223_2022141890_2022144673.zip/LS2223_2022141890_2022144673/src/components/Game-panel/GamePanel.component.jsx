import { useState,useEffect } from "react"
import "./GamePanel.css"
import Tictac from "../Board/Board.component"
import ScoreBoard from "../ScoreBoard/ScoreBoard.component"
import { getRandom } from "../../helpers"

 
function GamePanel  (props)  {  
    const {isVisible,gameStarted,xPlayer,setXPlayer,winnertime,showwinnertime,selectedLevel}=props
    const gameStartedClass = isVisible ? "show" : "hide";
    const winnerfinal = showwinnertime ? "show" : "hide";



    const win_conditions=[
        [0,1,2],
        [3,4,5],
        [6,7,8],
        [0,3,6],
        [1,4,7],
        [2,5,8],
        [0,4,8],
        [2,4,6],
    ]

    const [board1,setBoard1]=useState(Array(9).fill(null));
    const [board2,setBoard2]=useState(Array(9).fill(null));
    const [board3,setBoard3]=useState(Array(9).fill(null))
    const [board4,setBoard4]=useState(Array(9).fill(null))
    const [board5,setBoard5]=useState(Array(9).fill(null))
    const [board6,setBoard6]=useState(Array(9).fill(null))
    const [board7,setBoard7]=useState(Array(9).fill(null))
    const [board8,setBoard8]=useState(Array(9).fill(null))
    const [board9,setBoard9]=useState(Array(9).fill(null))


    const [gameover,setGameover] = useState(false)
    const [gameover1,setGameover1]=useState(false);
    const [gameover2,setGameover2]=useState(false);
    const [gameover3,setGameover3]=useState(false);
    const [gameover4,setGameover4]=useState(false);
    const [gameover5,setGameover5]=useState(false);
    const [gameover6,setGameover6]=useState(false);
    const [gameover7,setGameover7]=useState(false);
    const [gameover8,setGameover8]=useState(false);
    const [gameover9,setGameover9]=useState(false);

    const [winner1, setWinner1] = useState(null)
    const [winner2, setWinner2] = useState(null)
    const [winner3, setWinner3] = useState(null)
    const [winner4, setWinner4] = useState(null)
    const [winner5, setWinner5] = useState(null)
    const [winner6, setWinner6] = useState(null)
    const [winner7, setWinner7] = useState(null)
    const [winner8, setWinner8] = useState(null)
    const [winner9, setWinner9] = useState(null)
    const [scores,setScores] = useState({xScore:0,oScore:0});
    const [completedBoards, setCompletedBoards] = useState(0);
 
    

                
    const HandleBoxClick = (boxIdx,Board, setBoard, gameOver, setGameOver, setWinner) => {
            if(gameOver || OverallWinner || showwinnertime ){
                return
            }
           
            const updatedBoard = Board.map((value,idx)=>{
            if(idx===boxIdx){
               return xPlayer === true ? "X" : "O"
            }
            else {
                return value;
            }
        })

        setBoard(updatedBoard)
        setXPlayer(!xPlayer)
    
        const checkwinner = (board) => {
        for(let i=0; i<win_conditions.length;i++){
            const[x,y,z] = win_conditions[i];

        if(board[x] && board[x] === board[y] && board[y] === board[z]){
            
            return board[x];
        }
    } 


}
    

       
        const winner = checkwinner(updatedBoard);
             
        if(winner){
            
             setWinner(winner)
             
            if(winner==='O'){
                let {oScore} = scores;
                oScore++;
                setScores({... scores,oScore}) //MANTER TODOS OS VALORES IGUAIS EXCETO O NOVO VALOR DA PONTUACAO
                
              }
              if(winner==='X'){
                let {xScore} = scores;
                xScore++;
                setScores({... scores,xScore})
           
                   
        }
                setGameOver(true)
                setCompletedBoards(completedBoards + 1);

                
            }   
            
            else if (!updatedBoard.includes(null)) {
             // Verifica se o tabuleiro está cheio (sem células vazias restantes)
              setGameOver(true);
              setCompletedBoards(completedBoards + 1);
            }
            
            
      };

      const playAgainstComputer = (board, setBoard, gameOver, setGameOver, setWinner, xPlayer, selectedLevel) => {
        
        
        // Gera uma posição aleatória válida
        let randomIdx;
        do {
          randomIdx = getRandom(0, 8);
        } while (board[randomIdx] !== null);
      
        // PC joga
        const updatedBoardPC = board.map((value, idx) => {
          if (idx === randomIdx) {
            return "O";
          } else {
            return value;
          }
        });
      
        setBoard(updatedBoardPC);
        setXPlayer(!xPlayer);
      
              const checkWinner = (board) => {
                for (let i = 0; i < win_conditions.length; i++) {
                  const [x, y, z] = win_conditions[i];
      
                  if (board[x] && board[x] === board[y] && board[y] === board[z]) {
                    return board[x];
                  }
                }
      
                return null;
              };
      
              const winnerPC = checkWinner(updatedBoardPC);
      
              if (winnerPC) {
                setWinner(winnerPC);
      
                if (winnerPC === "O") {
                  let { oScore } = scores;
                  oScore++;
                  setScores({ ...scores, oScore });
                }
                if (winnerPC === "X") {
                  let { xScore } = scores;
                  xScore++;
                  setScores({ ...scores, xScore });
                }
      
                setGameOver(true);
                setCompletedBoards(completedBoards + 1);
              }
              else if (!updatedBoardPC.includes(null)) {
                // Verifica se o tabuleiro está cheio (sem células vazias restantes)
                 setGameOver(true);
                 setCompletedBoards(completedBoards + 1);
               }
            }
          
        
        

        useEffect(() => {
        if (selectedLevel === "1" && !xPlayer && !gameover1) {
        playAgainstComputer(board1, setBoard1, gameover1, setGameover1, setWinner1, xPlayer, selectedLevel);
        }
        }, [board1]);

        useEffect(() => {
        if (selectedLevel === "1" && !xPlayer && !gameover2) {
          playAgainstComputer(board2, setBoard2, gameover2, setGameover2, setWinner2, xPlayer, selectedLevel);
        }
        }, [board2]);

        useEffect(() => {
        if (selectedLevel === "1" && !xPlayer && !gameover3) {
          playAgainstComputer(board3, setBoard3, gameover3, setGameover3, setWinner3, xPlayer, selectedLevel);
      }
      }, [board3]);

        useEffect(() => {
        if (selectedLevel === "1" && !xPlayer && !gameover4) {
          playAgainstComputer(board4, setBoard4, gameover4, setGameover4, setWinner4, xPlayer, selectedLevel);
        }
      }, [board4]);

        useEffect(() => {
      if (selectedLevel === "1" && !xPlayer && !gameover5) {
        playAgainstComputer(board5, setBoard5, gameover5, setGameover5, setWinner5, xPlayer, selectedLevel);
      }
    }, [board5]);

        useEffect(() => {
        if (selectedLevel === "1" && !xPlayer && !gameover6) {
          playAgainstComputer(board6, setBoard6, gameover6, setGameover6, setWinner6, xPlayer, selectedLevel);
        }
      }, [board6]);

        useEffect(() => {
        if (selectedLevel === "1" && !xPlayer && !gameover7) {
          playAgainstComputer(board7, setBoard7, gameover7, setGameover7, setWinner7, xPlayer, selectedLevel);
        }
      }, [board7]);

      useEffect(() => {
      if (selectedLevel === "1" && !xPlayer && !gameover8) {
        playAgainstComputer(board8, setBoard8, gameover8, setGameover8, setWinner8, xPlayer, selectedLevel);
      }
      }, [board8]);

      useEffect(() => {
      if (selectedLevel === "1" && !xPlayer && !gameover9) {
        playAgainstComputer(board9, setBoard9, gameover9, setGameover9, setWinner9, xPlayer, selectedLevel);
      }
      }, [board9]);


    const getWinnerSymbol = (winner) => {
        if(winner === "X"){
            return <div className="Winner-X"> X </div>}
        else if (winner === "O"){
            return <div className="Winner-O"> O </div>}
        
    }

    const getOverallWinner = (winners) => {
    
    
      for (const winConditions of win_conditions) {
        const [x, y, z] = winConditions;
        const winner = winners[x];
    
        if (winner && winners[y] === winner && winners[z] === winner) {
          return winner;
        }
      }
   
    
  }
  
  const OverallWinner = getOverallWinner([winner1, winner2, winner3, winner4, winner5, winner6, winner7, winner8, winner9]);
    
  
    const resetBoard = () =>{
        setGameover1(false)
        setBoard1(Array(9).fill(null))
        setBoard2(Array(9).fill(null))
        setBoard3(Array(9).fill(null))
        setBoard4(Array(9).fill(null))
        setBoard5(Array(9).fill(null))
        setBoard6(Array(9).fill(null))
        setBoard7(Array(9).fill(null))
        setBoard8(Array(9).fill(null))
        setBoard9(Array(9).fill(null))
        setScores({ ...scores, xScore: 0, oScore: 0 });
        setWinner1(null)
        setWinner2(null)
        setWinner3(null)
        setWinner4(null)
        setWinner5(null)
        setWinner6(null)
        setWinner7(null)
        setWinner8(null)
        setWinner9(null)
        setCompletedBoards(0);
    };

   
    useEffect(
        ()=>{
            if(gameStarted){
            resetBoard();}
            }
        ,[gameStarted]
    );
            
    
                

    return (
        
        <div id="game-panel" className={`${gameStartedClass}`}>
            
            
            <ScoreBoard scores={scores} xPlayer={xPlayer} completedBoards={completedBoards}/>
          
        <div className="game-board" > 
            <h3 className="sr-only">Peças do Jogo</h3>
            
            <div className='cell'>  
                {getWinnerSymbol(winner1)}
                <Tictac Board={board1} onClick={(idx) =>  HandleBoxClick(idx, board1, setBoard1, gameover1, setGameover1, setWinner1)} />
            
                
            </div>

            <div className='cell'>  
                {getWinnerSymbol(winner2)}
                <Tictac Board={board2} onClick={(idx) => HandleBoxClick(idx, board2, setBoard2, gameover2, setGameover2, setWinner2)}/>
                
            </div>

            <div className='cell'>
                {getWinnerSymbol(winner3)}  
                <Tictac Board={board3} onClick={(idx) => HandleBoxClick(idx, board3, setBoard3, gameover3, setGameover3, setWinner3)}/>
            </div>

            <div className='cell'>
                {getWinnerSymbol(winner4)}  
                <Tictac Board={board4} onClick={(idx) =>  HandleBoxClick(idx, board4, setBoard4, gameover4, setGameover4, setWinner4)}/>
            </div>

            <div className='cell'> 
                {getWinnerSymbol(winner5)} 
                <Tictac Board={board5} onClick={(idx) => HandleBoxClick(idx, board5, setBoard5, gameover5, setGameover5, setWinner5)}/>
            </div>
            
            <div className='cell'> 
                {getWinnerSymbol(winner6)} 
                <Tictac Board={board6} onClick={(idx) => HandleBoxClick(idx, board6, setBoard6, gameover6, setGameover6, setWinner6)}/>
            </div>

            <div className='cell'> 
                {getWinnerSymbol(winner7)} 
                <Tictac Board={board7} onClick={(idx) => HandleBoxClick(idx, board7, setBoard7, gameover7, setGameover7, setWinner7)}/>
            </div>

            <div className='cell'> 
                {getWinnerSymbol(winner8)} 
                <Tictac Board={board8} onClick={(idx) => HandleBoxClick(idx, board8, setBoard8, gameover8, setGameover8, setWinner8)}/>
            </div>

            <div className='cell'> 
                {getWinnerSymbol(winner9)} 
                <Tictac Board={board9} onClick={(idx) => HandleBoxClick(idx, board9, setBoard9, gameover9, setGameover9, setWinner9)}/>
            </div> 
            
            
            </div>
            <div className={`winner ${winnertime === 'X' ? 'winner-red' : (winnertime === 'O' ? 'winner-blue' : '')} ${winnerfinal}`}>GANHOU {winnertime}</div>
            {OverallWinner && (
            <div className={`${OverallWinner === 'X' ? 'winner-red' : (OverallWinner === 'O' ? 'winner-blue' : '')}`}>GANHOU {OverallWinner}</div>
            )}
            
            </div>  
    );

            }
export default GamePanel