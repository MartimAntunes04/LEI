export {default as Header} from "./Header/header.component"
export {default as Footer} from "./Footer/footer.component"
export {default as ControlPanel} from "./Control-panel/control-panel.component"
export {default as ScoreBoard} from "./ScoreBoard/ScoreBoard.component"
export {default as GamePanel} from"./Game-panel/GamePanel.component"


