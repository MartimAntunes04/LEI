import React from "react";
import "./ScoreBoard.css"


function ScoreBoard({scores,xPlayer,completedBoards}){
    const {xScore,oScore}=scores
     // caso o jogo acabe, o vencedor é quem tem mais tictactoes ganhos
     let OverallWinner = null;

     if (completedBoards === 9 && xScore !== oScore) {
         OverallWinner = xScore > oScore ? "X" : "O";
     }         
   
    return(
    <div className="scoreboard">
        <span className={`score x-score ${!xPlayer && "inactive"}`}>X - {xScore}</span> 
        <span className={`score o-score ${xPlayer && "inactive"}`}>O - {oScore}</span> 

        {completedBoards === 9 && OverallWinner && ( 
            <span className={`${OverallWinner === 'X' ? 'winner-red' : (OverallWinner === 'O' ? 'winner-blue' : '')}`}>GANHOU {OverallWinner}</span>
        )}
    </div>
    );
}


export default ScoreBoard