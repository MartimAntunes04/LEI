
import { useState } from "react";
import './assets/styles/App.css';
import {TIMEOUTGAME} from "./constants";
import { useEffect } from 'react';
import { getRandom } from "./helpers";


import{
    Header, 
    Footer,
    ControlPanel,
    GamePanel,

    
  } from "./components"


function App() {


const [xPlayer,setXPlayer] = useState(true)
const [gameStarted,setGameStarted]=useState(false);
const [gameover,setGameover]=useState(false);
const [selectedLevel, setSelectedLevel] = useState("0");
const [timerX,setTimerX]=useState(TIMEOUTGAME);
const [timerO,setTimerO]=useState(TIMEOUTGAME);
const [nick1, setNick1] = useState(""); //[nickname, letra]
const [nick2, setNick2] = useState(""); //[nickname, letra]
const [isNickValid, setNickValid] = useState(true);
const [isGamePanelVisible, setIsGamePanelVisible] = useState(false);
const [player1Symbol, setPlayer1Symbol] = useState("");
const [player2Symbol, setPlayer2Symbol] = useState("");
const [winner, setWinner] = useState(null);
const [showwinner,setShowwinner]=useState(false);


let timerIdX=undefined;  
let timerIdO=undefined;

  useEffect(() => {
    
    if (gameStarted) {
      if (xPlayer) {
        timerIdX = setInterval(() => {
          setTimerX((previousState) => {
            const nextTimerX = previousState - 1;
            if (nextTimerX === 0) {
              setGameStarted(false);
              setGameover(true)
              setWinner(xPlayer ? 'O' : 'X');
              setShowwinner(true)
              
            }
            return nextTimerX;
          });
        }, 1000);
      } else if (!xPlayer) {
        
        timerIdO = setInterval(() => {
          setTimerO((previousState) => {
            const nextTimerO = previousState - 1;
            if (nextTimerO === 0) {
              setGameStarted(false);
              
              setWinner(xPlayer ? 'O' : 'X');
              setShowwinner(true);
              
              setGameover(true)
            }
            return nextTimerO;
          });
        }, 1000);
      }
    } else {
      clearInterval(timerIdX);
      clearInterval(timerIdO);
      setTimerX(TIMEOUTGAME);
      setTimerO(TIMEOUTGAME);
    }
  
    return () => {
      clearInterval(timerIdX);
      clearInterval(timerIdO);
    };
  }, [gameStarted, xPlayer]);
  
  
  
  
  
  
  /**
  * When the game starts
  */
  
  const handleGameStart = () => {
    if (gameStarted) {
      setGameStarted(false);
      setIsGamePanelVisible(false);
      resetGame()
    } else {//começar jogo
      switch(selectedLevel){ //verificar se campos estão preenchidos
        case '1':
          if(nick1.length === 0){
            setNickValid(false);
            return;
          }
          break;
        case '2':
          let aux = false;
          if(nick1.length === 0){
            setNickValid(false);
            aux=true;
          }
          if(nick2.length === 0){
            setNickValid(false);
            aux=true;
          }
          if(aux){
            return;
          }
          break;
        default:
          break;
      }
      setNickValid(true);
      setIsGamePanelVisible(true);
      
      //jogo começa
      //chamar a função para ir buscar os valores de X e O para o jogador
      // 1 - X
      // 2 - O
      let aux = getRandom(1, 2);
      switch (aux) {
        case 1:
         
          setPlayer1Symbol("X");
          setPlayer2Symbol("O");
          break;
        case 2:
         
          setPlayer1Symbol("O");
          setPlayer2Symbol("X");
          break;
        default:
          break;
      }
      setGameStarted(true);
    }
  };


  const handleChangePlayer = () => {
    setXPlayer((prevXPlayer) => !prevXPlayer);
  };

  
  const handleLevelChange = (event) =>{
  const level = event.currentTarget.value;
  setSelectedLevel(level);
  

  
}
/*
* Quando insere nome no nick1
*/
const handleNick1Change = (event) => {
 setNick1([]);
 setNick1(event.target.value);
};

/*
* Quando insere nome no nick2
*/
const handleNick2Change = (event) => {
 setNick2([]);
 setNick2(event.target.value);
};


const resetGame = () => {
    setGameStarted(false);
  setIsGamePanelVisible(false);
  setNick1("")
  setNick2("")
  setPlayer1Symbol("");
  setPlayer2Symbol("");
  setWinner("");
  setShowwinner("");
    
  };


      
  return (
    <div id="container">
      <Header/>
      <main className="main-content">
      
    
      <ControlPanel
      gameStarted={gameStarted}
      onGameStart={handleGameStart}
      selectedLevel={selectedLevel}
      onLevelChange={handleLevelChange}
      timerX={timerX}
      timerO={timerO}
      onNick1Change={handleNick1Change}
      onNick2Change={handleNick2Change}
      isNickValid={isNickValid}
      player1Symbol={player1Symbol}
      player2Symbol={player2Symbol}
      nick1={nick1}
      nick2={nick2}
      
      />
   
      <GamePanel
      isVisible={isGamePanelVisible}
      gameStarted={gameStarted}
      gameover={gameover}
      xPlayer={xPlayer}
      setXPlayer={handleChangePlayer}
      winnertime={winner}
      showwinnertime ={showwinner}
      selectedLevel={selectedLevel}
      onLevelChange={handleLevelChange}
      
     
      />
      
       </main>
      <Footer/>
    </div>
  );
}

export default App;
