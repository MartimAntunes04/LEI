//
// Created by ASUS on 11/10/2023.
//

#include "ponto.h"
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

Ponto::Ponto(int x, int y) {
    c_x = x;
    c_y = y;

    cout << "Construction Ponto Object " << getAsString();
}



int Ponto ::getx() const {
    return c_x;
}

int Ponto ::gety() const {
    return c_y;
}

void Ponto ::setx(int newx) {
    c_x = newx;
}

void Ponto ::sety(int newy)  {
    c_y = newy;
}

string Ponto::getAsString() const {
    ostringstream os;
    os << "x: "<< c_x << " y: " << c_y;
    return os.str();
}

double Ponto::calcula_Distancia(const Ponto &outro_ponto) {
    int deltax = c_x - outro_ponto.c_x;
    int deltay = c_y - outro_ponto.c_y;
    return sqrt(deltax * deltax + deltay  * deltay);
}


