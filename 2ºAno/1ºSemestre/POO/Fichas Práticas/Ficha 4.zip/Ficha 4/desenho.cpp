//
// Created by ASUS on 30/10/2023.
//
#include "desenho.h"
#include "retangulo.h"
using namespace std;
Desenho::Desenho(std::string n) {
    nome=n;
}

string Desenho::getString() const {
    ostringstream os;
    os << "Nome: " << nome << endl;
    for(auto var : v){
        os << "\t" << var.getString() << endl;

    }
    return os.str();
}