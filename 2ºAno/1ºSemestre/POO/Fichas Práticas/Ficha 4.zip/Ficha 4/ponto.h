//
// Created by ASUS on 11/10/2023.
//

#ifndef FICHA_4_PONTO_H
#define FICHA_4_PONTO_H

#include <string>
#include <cmath>

class Ponto{

    int c_x,c_y;
public:
    Ponto(int x,int y);

    std::string getAsString() const;
    int getx() const;
    int gety() const;
    void setx(int newx) ;
    void sety(int newy) ;
    double calcula_Distancia(const Ponto &outro_ponto);




};






#endif //FICHA_4_PONTO_H
