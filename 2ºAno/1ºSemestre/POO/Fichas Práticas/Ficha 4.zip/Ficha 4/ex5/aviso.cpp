//
// Created by ASUS on 18/10/2023.
//

#include "prego.h"
#include "aviso.h"
#include <iostream>
#include <sstream>
using namespace std;


Aviso::Aviso(string text, Prego &p1)  {
    ref=&p1;
    texto=text;

}

string Aviso::getString() const {
    ostringstream os;
    os << texto << " no local  " << ref->getstring();
    return os.str();
}

void Aviso::mudadePrego(Prego &p) {
    ref=&p;
}