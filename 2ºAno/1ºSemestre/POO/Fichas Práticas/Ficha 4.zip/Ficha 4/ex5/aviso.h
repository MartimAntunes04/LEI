//
// Created by ASUS on 18/10/2023.
//

#ifndef EX5_AVISO_H
#define EX5_AVISO_H
#include "prego.h"
class Aviso{

    std::string texto;
    Prego * ref;

public:
    Aviso(std::string text,Prego &p1);

    std::string getString()const;

    void mudadePrego(Prego &p);
};




#endif //EX5_AVISO_H
