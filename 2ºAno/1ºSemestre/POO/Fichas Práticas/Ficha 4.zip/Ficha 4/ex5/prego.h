//
// Created by ASUS on 18/10/2023.
//

#ifndef EX5_PREGO_H
#define EX5_PREGO_H
#include <iostream>

class Prego{
    int x,y;
public:
    int getY() const {
        return y;
    }

    void setY(int y) {
        Prego::y = y;
    }

public:
    int getX() const {
        return x;
    }

    void setX(int x) {
        Prego::x = x;
    }

public:
    Prego(int a, int b);

   // ~Prego() {
     //   std::cout << "desconstruindo prego em " << x << "," << y << "\n";
   // }


    void mudaDeSitio(int newx, int newy);
     std::string getstring() const;


};





#endif //EX5_PREGO_H
