//
// Created by ASUS on 18/10/2023.
//
#include <iostream>
#include "prego.h"
#include <string>
using namespace std;
Prego::Prego(int a, int b) {
    x  = a;
    y = b;

}


string Prego :: getstring() const{
    return "("  + to_string(x) + "/" + to_string(y) + ")";
}

void Prego::mudaDeSitio(int newx, int newy) {
    x = newx; y = newy;
}

