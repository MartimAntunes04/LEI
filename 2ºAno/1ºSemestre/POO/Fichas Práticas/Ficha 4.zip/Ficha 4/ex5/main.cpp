#include <iostream>
#include "prego.h"
#include "aviso.h"
using namespace std;
int main() {

    Prego a(1,2);
    Prego b(5, 8);


    Aviso a1("Piso molhado",a);
    Aviso a2("FECHADO",b);

    cout << a1.getString()<< endl;

    a1.mudadePrego(b);
    cout << a1.getString()<<endl;


    a.mudaDeSitio(3,7);
    cout << a1.getString()<< endl;
    return 0;
}
