//
// Created by ASUS on 30/10/2023.
//

#ifndef FICHA_4_DESENHO_H
#define FICHA_4_DESENHO_H
#include <iostream>
#include "retangulo.h"
#include "vector"
class Desenho{
    std::string nome;
    std::vector<Retangulo> v;

public:
    Desenho(std::string n);
    std::string getString()const;

};
#endif //FICHA_4_DESENHO_H
