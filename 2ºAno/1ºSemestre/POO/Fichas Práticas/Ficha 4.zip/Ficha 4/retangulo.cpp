//
// Created by ASUS on 30/10/2023.
//
#include "retangulo.h"
#include "ponto.h"
#include <sstream>
using namespace std;


string Retangulo::getString() const {
    ostringstream os;
    os << "CSE:  (" << cse.getAsString() <<") << Largura: " << larg << "Altura:" << alt;
    return os.str();
}

float Retangulo::getArea() const {
    return larg*alt;
}