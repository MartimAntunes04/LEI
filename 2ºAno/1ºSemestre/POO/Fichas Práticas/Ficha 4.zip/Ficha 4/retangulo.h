//
// Created by ASUS on 30/10/2023.
//

#ifndef FICHA_4_RETANGULO_H
#define FICHA_4_RETANGULO_H
#include <sstream>
#include "ponto.h"

class Retangulo{
    Ponto cse;
    int larg,alt;

public:
    Retangulo(Ponto a,int largura,int altura) : cse(a),larg(largura),alt(altura){}
    std::string getString()const;
    float getArea()const;
};



#endif //FICHA_4_RETANGULO_H
