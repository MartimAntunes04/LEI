//
// Created by ASUS on 30/10/2023.
//
#include <iostream>
#include <sstream>
#include "registocivil.h"
#include "pessoa.h"
#include <fstream>
using namespace std;

RegistoCivil::RegistoCivil(const std::string &n): pais(n), total(0) {
    cout << "A construir Registo Civil " << pais<< endl;
}

RegistoCivil::~RegistoCivil() {
    cout << "Destrindo Registo Civil" << pais << endl;
}

string RegistoCivil::getString() const {
    ostringstream os;
    os << "Registo Civil " << pais << " com os " << total << " registos:\n";
    for(const Pessoa &p:fichas)
        if(p.getId()!=0)
            os<<p.getString();
    return os.str();
}

string RegistoCivil::getPais() const {
    return pais;
}

int RegistoCivil::verifica(int num_ident) const {  //Se existir retorna o índice , se não é -1
    int indice=-1;
    for(int i=0;i<max;i++){
        if(fichas[i].getId()==num_ident){
            indice = i;
            break;
        }
    }
    return indice;
}

bool RegistoCivil::regista(string &n,long num_ident,long num_cont){
    if(verifica(num_ident) == -1 && total < max){
        for(int i=0; i < max; i++)//encontrar uma posição vaga
            if(fichas[i].getId()==0){
                fichas[i]=Pessoa(n, num_ident, num_cont);
                total++;
                return true;
            }
        //Se não encontrou uma vaga é porque está cheio
    }
    return false;
}



void RegistoCivil::registaDoFicheiro(const std::string &ficheiro) {
    ifstream fich(ficheiro);
    if(fich) {//ficheiro encontrado e aberto
        string linha,parte;
        int nif,id;
        while(getline(fich,linha)){
            istringstream is(linha);
            if(is>>parte && is >> id && is >> nif){
                regista(parte,id,nif);
                printf("ja ta");
            }
        }
    }
}

string RegistoCivil::getPessoaNome(int num_ident) const {
    int indice;
    for(int i=0;i<max;i++){
        if((indice= verifica(num_ident))!=-1){
           return fichas[indice].getNome();
        }
    }
    return "Nao encontrado";
}

bool RegistoCivil::apaga(int num_ident) {
    int indice;
    if((verifica(num_ident))==-1){
        return false;
    }
    fichas[indice]=Pessoa();
    total--;
    return true;
}

bool RegistoCivil::atualizanome(int num_ident, string &n) {
    int indice;
    if((verifica(num_ident))!=-1){
        fichas[indice].setNome(n);
        return true;
    }
    return false;
}

int RegistoCivil::getTotal() const {
    return total;
}

Pessoa *RegistoCivil::getPessoa(int num_ident) {
    //Se não encontrar retorna nullptr
    int indice= verifica(num_ident);
    if(indice!=-1)
        return &(fichas[indice]);
    return nullptr;
}