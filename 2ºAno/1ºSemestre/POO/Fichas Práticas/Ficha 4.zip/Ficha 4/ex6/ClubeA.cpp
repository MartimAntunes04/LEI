//
// Created by ASUS on 31/10/2023.
//
#include "sstream"
#include "ClubeA.h"
using namespace std;

ClubeA::ClubeA(const string &name, const string &descricao, RegistoCivil &r) : nome(name),texto(descricao),registo(r){
    for(int id:ids){
        id=0;
    }
    total=0;
    cout << "Contruir clube" << nome << endl;

}

ClubeA::~ClubeA() {
    cout << "Destruir clube" << nome << endl;
}

int ClubeA::verifica(int search_id) const {
    for(int id:ids){
        if(search_id=id)
            return true;
    }
    return false;
}

bool ClubeA::increve(int id) {
    if(verifica(id) || total==max)
        return false;
    for(int &i:ids)
        if(i==0){
            i=id;
            total++;
            return true;
        }
}

string ClubeA::getAsString() const {
    ostringstream os;
    os << "O clube" << nome << "tem no total " << total <<"socios\n";
    for(int id:ids)
        os << registo.getPessoaNome(id)<< '\t';
    os<<endl;
    return os.str();
}