//
// Created by ASUS on 31/10/2023.
//

#ifndef EX6_CLUBEB_H
#define EX6_CLUBEB_H
#include "pessoa.h"
#include <iostream>
class ClubeB{
    string nome,descricao;
    static const int max=50;
    Pessoa *pessoas[max];
    int total;

public:
    ClubeB(const string &name,const string &texto);
    ~ClubeB();
    bool  verifica(int search_id)const;
    bool inscreve(Pessoa &p);
    string getString()const;
};

#endif //EX6_CLUBEB_H
