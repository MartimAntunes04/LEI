//
// Created by ASUS on 30/10/2023.
//

#ifndef EX6_REGISTOCIVIL_H
#define EX6_REGISTOCIVIL_H
#include <iostream>
#include <sstream>
#include "pessoa.h"
using namespace std;
class RegistoCivil{
    static const int max = 50;
    string pais;
    Pessoa fichas[max];
    int total;

public:
    RegistoCivil(const string &n);
    ~RegistoCivil();

    string getString()const;
    string getPais()const;
    bool regista(string &name,long num_ident,long num_cont);
    int verifica(int num_ident)const;
    void registaDoFicheiro(const std::string & ficheiro);
    string getPessoaNome(int num_ident)const;
    bool apaga(int num_ident);
    bool atualizanome(int num_ident,string &n);
    int getTotal()const;
    Pessoa *getPessoa(int num_ident);

};

#endif //EX6_REGISTOCIVIL_H
