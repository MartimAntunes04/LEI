//
// Created by ASUS on 31/10/2023.
//

#ifndef EX6_CLUBEA_H
#define EX6_CLUBEA_H
#include <sstream>
#include <iostream>
#include "registocivil.h"
using namespace std;
class ClubeA{
    string nome,texto;
    static const int max=50;
    int ids[max];
    RegistoCivil &registo;
    int total;
public:
    ClubeA(const string &name,const string &descricao,RegistoCivil &r);
    ~ClubeA();
    int verifica(int search_id)const;
    bool increve (int id);
    string getAsString()const;

};

#endif //EX6_CLUBEA_H
