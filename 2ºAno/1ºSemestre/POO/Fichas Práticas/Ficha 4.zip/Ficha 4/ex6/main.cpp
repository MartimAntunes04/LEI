#include <iostream>
#include "pessoa.h"
#include "registocivil.h"
#include "ClubeA.h"
#include "ClubeB.h"
using namespace std;
int main() {
    Pessoa a("Martim ",232939019,255718403);
  //  cout << a.getString() << endl;

  //  a.atualizanome("Miguel");
  //  cout << a.getString()<< endl;

RegistoCivil r1("Portugal");


    ClubeA slb("SLB","Sport Lisboa e Benfica",r1);
    //slb.increve(5678);


    ClubeB aac("AAC","Associacao Academica de Coimbra");
   // aac.inscreve(*r1.getPessoa(5678));

    //cout << endl << slb.getAsString();
    //cout << endl << aac.getString();
    //while(cin.get()!='\n');
    //Problema - qual versão será robusta (por enquanto) caso a pessoa deixe de existir?
    //r1.apaga(5678);

    //r1.regista("Rita",323,32335778);
    r1.registaDoFicheiro("registocivil.txt");
    cout << r1.getString();
    while(cin.get()!='\n');
    return 0;
}
