//
// Created by ASUS on 31/10/2023.
//
#include <sstream>
#include <iostream>
#include "ClubeB.h"
using namespace std;

ClubeB::ClubeB(const string &name, const string &texto) : nome(name),descricao(texto){
    for(int i=0;i<max;i++){
        pessoas[i]= nullptr;
    }
    total=0;
    cout << "Contruindo clube" << nome << endl;
}

ClubeB::~ClubeB() {
    cout << "Destruindo clube" << nome << endl;
}

bool ClubeB::verifica(int search_id) const {
    for(Pessoa *p:pessoas){
        if(p!= nullptr && p->getId())
            return true;
    }
    return false;
}

bool ClubeB::inscreve(Pessoa &p) {
    //Se for já socia
    if(verifica(p.getId()) || total==max)
        return false;
    for(int i=0;i<max;i++){
        if(pessoas[i]== nullptr){
            pessoas[i]=&p;
            total++;
            return true;
        }
    }
    return false;  //Se não saiu pelo return true
}

string ClubeB::getString() const {
    ostringstream os;
    os << "Clube " << nome << "com total " << total << "socios\n";
    for(Pessoa *p:pessoas)
        if(p)  //Não é nullptr
            os << p->getNome() << '\t';
    os<<endl;
    return os.str();

}