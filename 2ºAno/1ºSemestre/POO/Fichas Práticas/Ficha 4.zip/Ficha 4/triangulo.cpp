//
// Created by ASUS on 11/10/2023.
//
#include "triangulo.h"
using namespace std;




