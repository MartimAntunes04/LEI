//
// Created by ASUS on 11/10/2023.
//



#ifndef FICHA_4_TRIANGULO_H
#define FICHA_4_TRIANGULO_H
#include <string>
#include "ponto.h"





#endif //FICHA_4_TRIANGULO_H
