#include <iostream>
#include "ponto.h"
#include "triangulo.h"
#include "retangulo.h"
#include "desenho.h"
using namespace std;
int main() {


    Ponto a(1,2);
    Ponto b(3,4);
    Ponto c (5,6);
    cout << "\nPonto a:" << a.getAsString() << endl;
    cout << "Ponto b:" << b.getAsString() << endl;
    cout << "Distancia:" << a.calcula_Distancia(b);
    cout <<  "\nPonto c: " << c.getAsString()<< endl;

    cout << "Novo ponto c: " << c.getAsString() << endl;


    Retangulo r(a,2,3);
    cout << r.getString();
    cout << "\nArea= " << r.getArea();


    Desenho d1("Sol");
    cout << "\n" <<d1.getString();

    return 0;
}
