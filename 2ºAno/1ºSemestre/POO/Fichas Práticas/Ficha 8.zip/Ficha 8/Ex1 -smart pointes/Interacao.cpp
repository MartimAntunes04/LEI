//
// Created by ASUS on 20/12/2023.
//
#include "Interacao.h"
#include "FabricaObjetos.h"

using namespace std;

Interacao::Interacao(RegistoPredial & r): rp(r){} //por omissão unique_ptr é nullptr

void Interacao::executa() {
    string comando, restoLinha;
    istringstream is;
    do {
        restoLinha = Comando::leComando(comando);
        istringstream is(restoLinha);
        //delete atual; //apagar o comando atual Não é preciso com smartpointer
        atual = std::move(FabricaObjetos::getComando(comando));
        if(comando == "list")
            cout << rp.getAsString();
        else
        if(atual != nullptr &&  atual->executa(is, rp))
            cout << "\nComando executado com sucesso\n";
        else
            cout << "\ncomando invalido ou ainda não implementado\n";
    }while(comando != "sai");
}


Interacao::~Interacao() {
    //delete atual;
}
