//
// Created by ASUS on 20/12/2023.
//
#include "Apartamento.h"
using namespace std;
Apartamento::Apartamento(int area, int andar,int n_a):
        Imovel("apartamento",area, area*10, andar){
    this->n_assoalhadas= n_a;
    //std::cout << "A construir apartamento";
}
/*Apartamento::~Apartamento(){
    std::cout << "A destruir apartamento";
}*/

shared_ptr< Imovel> Apartamento::duplica() const{
    return make_shared<Apartamento>(*this);
}
std::string Apartamento::getAsString() const{
    std::ostringstream os;
    os << "T" << n_assoalhadas <<
       Imovel::getAsString();
    return os.str();
}