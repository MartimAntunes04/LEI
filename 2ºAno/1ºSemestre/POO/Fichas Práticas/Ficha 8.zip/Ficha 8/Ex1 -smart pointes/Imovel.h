//
// Created by ASUS on 20/12/2023.
//

#ifndef EX1__SMART_POINTES_IMOVEL_H
#define EX1__SMART_POINTES_IMOVEL_H
#include <string>
#include <sstream>
#include <iostream>
#include <memory>

class Imovel {
    int andar, area, preco;
    std::string codigo;
    static int contador;
public:
    Imovel(const std::string & tipo, int area, int preco, int andar);
    //virtual ~Imovel();
    virtual std::shared_ptr<Imovel> duplica() const=0;
    virtual std::string getAsString() const;
    int getAndar()const;
    std::string getCodigo()const;
};
std::ostream & operator<<(std::ostream &o, const Imovel & im);

#endif //EX1__SMART_POINTES_IMOVEL_H
