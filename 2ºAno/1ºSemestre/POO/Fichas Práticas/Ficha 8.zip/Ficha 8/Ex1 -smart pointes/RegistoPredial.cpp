//
// Created by ASUS on 20/12/2023.
//
#include "RegistoPredial.h"
#include <sstream>

using namespace std;
bool RegistoPredial::acrescenta(shared_ptr<Imovel> & im){
    auto wp = pesquisa(im->getCodigo());
    if(!wp.lock()) { //Se não existe já
        imoveis.emplace_back(im->duplica()); //é mais seguro criar uma cópia do objeto e guardar
        return true;
    }
    return false;
}
RegistoPredial::~RegistoPredial(){
    //for(Imovel *el: imoveis)
    //  delete el;
    cout << "Destruir registo Predial";
}

RegistoPredial::RegistoPredial(const RegistoPredial & outra){
    *this=outra;
}
RegistoPredial & RegistoPredial::operator=(const RegistoPredial & outra){
    if(this != &outra){
        // for(auto el: imoveis)
        //   delete el;
        imoveis.clear();
        imobiliarias.clear();
        //Outro objeto deve ser copiado para aqui
        for(auto el: outra.imoveis)
            imoveis.emplace_back(el->duplica());
        for(auto el: outra.imobiliarias)
            imobiliarias.insert(el);
        //cada imobiliaria deve ficar com os ponteiros acertados
        //para os novos imóveis
        for(auto el: imobiliarias){
            el.second.atualizaPonteiros(imoveis);
        }

    }
    return *this;
}

weak_ptr<Imovel> RegistoPredial::pesquisa(const std::string & cod ){
    for(int i=0; i < imoveis.size(); i++)
        if(imoveis.at(i)->getCodigo() == cod){
            return imoveis.at(i);
        }
    return {};
}

bool RegistoPredial::acrescenta(Imobiliaria  im) {
    if(imobiliarias.find(im.getNome()) == imobiliarias.end()) { //Não existe ainda
        imobiliarias.insert({im.getNome(),im});
        return true;
    }
    return false;
}

std::string RegistoPredial::getAsString() const {
    ostringstream os;
    os << "Registo Predial com " << imoveis.size() << " imoveis:\n";
    for(auto el: imoveis)
        os << el->getAsString() << endl;
    os << "----e com " << imobiliarias.size() << " imobiliarias:\n";
    for(const auto & el: imobiliarias)
        os << el.second.getAsString() << endl;
    return os.str();
}

bool RegistoPredial::anuncia(const std::string & codigo_imovel, const std::string & nome_imobiliaria) {
    auto el = imobiliarias.find(nome_imobiliaria);
    auto imov = pesquisa(codigo_imovel);
    if (el != imobiliarias.end() && imov.lock()) {
        return el->second.acrescenta(imov);
    }
    return false;
}