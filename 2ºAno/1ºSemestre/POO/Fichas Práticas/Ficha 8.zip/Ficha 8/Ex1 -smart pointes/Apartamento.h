//
// Created by ASUS on 20/12/2023.
//

#ifndef EX1__SMART_POINTES_APARTAMENTO_H
#define EX1__SMART_POINTES_APARTAMENTO_H
#include "Imovel.h"

class Apartamento:public Imovel {
    int n_assoalhadas;
public:
    Apartamento(int area, int andar,int n_a);
    //~Apartamento();
    std::string getAsString() const override;
    virtual std::shared_ptr<Imovel> duplica() const;
};
#endif //EX1__SMART_POINTES_APARTAMENTO_H
