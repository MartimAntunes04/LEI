//
// Created by ASUS on 20/12/2023.
//

#ifndef EX1__SMART_POINTES_IMOBILIARIA_H
#define EX1__SMART_POINTES_IMOBILIARIA_H
#include "Imovel.h"
#include <vector>
#include <memory>

class Imobiliaria {
    std::vector<std::weak_ptr<Imovel>> imoveis;
    std::string nome;

    int pesquisa(const std::string & codigo) const;
public:
    Imobiliaria(const std::string & nome);
    ~Imobiliaria();
    std::string obtemListaAndar(int andar);
    const std::string &getNome() const;
    bool remove(const std::string & codigo);
    bool acrescenta(std::weak_ptr<Imovel> im);
    std::string obtemPorCodigo(std::string codigo);
    std::string getAsString() const;
    void atualizaPonteiros(std::vector<std::shared_ptr<Imovel>> Imoveis);
};

#endif //EX1__SMART_POINTES_IMOBILIARIA_H
