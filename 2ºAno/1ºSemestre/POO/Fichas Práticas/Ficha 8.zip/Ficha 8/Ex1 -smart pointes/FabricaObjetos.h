//
// Created by ASUS on 20/12/2023.
//

#pragma once
#include <string>
#include "Imobiliaria.h"
#include "Imovel.h"
#include "Comando.h"
#include <map>
#include <memory>
using namespace std;

class FabricaObjetos{
    static const std::map<std::string, int> comandos;
public:
    static Imobiliaria getImobiliaria(istream & is);
    static std::shared_ptr< Imovel> getImovel(istream & is);
    static std::unique_ptr<Comando> getComando(const std::string & comando);
};