//
// Created by ASUS on 20/12/2023.
//
#include "Imovel.h"
int Imovel::contador = 0;

Imovel::Imovel(const std::string & tipo, int area, int preco, int andar): preco(preco), area(area), andar(andar) {
    std::ostringstream os;
    os << tipo << ++contador;
    codigo = os.str();
    std::cout << "A construir Imovel";
}
/*Imovel::~Imovel(){ //Tambem o da derivada será chamado
    std::cout << "A destruir imovel";
}*/
std::string Imovel::getAsString() const{
    std::ostringstream os;
    os << "Imovel:" << codigo << " "
       <<  area << "m2 " << preco  << " euros "
       << andar << "o andar ";
    return os.str();
}
int Imovel::getAndar()const{
    return andar;
}
std::string Imovel::getCodigo() const {
    return codigo;
}
std::ostream & operator<<(std::ostream &o, const Imovel & im){
    o << im.getAsString();
    return o;
}