//
// Created by ASUS on 20/12/2023.
//

#ifndef EX1__SMART_POINTES_INTERACAO_H
#define EX1__SMART_POINTES_INTERACAO_H
#include "RegistoPredial.h"
#include "Comando.h"
#include <memory>

class Interacao{
    RegistoPredial &rp;
    //Comando *atual;
    std::unique_ptr<Comando> atual;
public:
    Interacao(RegistoPredial & r);
    void executa();
    ~Interacao();
    //Proibido copiar intera��o
    Interacao(const Interacao &) = delete;
    Interacao& operator=(const Interacao &) = delete;
};
#endif //EX1__SMART_POINTES_INTERACAO_H
