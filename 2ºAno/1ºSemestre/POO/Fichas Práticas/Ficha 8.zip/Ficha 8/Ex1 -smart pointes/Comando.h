//
// Created by ASUS on 20/12/2023.
//

#ifndef EX1__SMART_POINTES_COMANDO_H
#define EX1__SMART_POINTES_COMANDO_H
#include <sstream>
#include "RegistoPredial.h"
class Comando {
public:
    Comando();
    static std::string leComando(std::string &com) ;
    virtual bool executa(std::istringstream &restoLinha,
                         RegistoPredial & rp) const=0;
};

class comandoAdImovel: public Comando{
public:
    bool executa(std::istringstream &restoLinha, RegistoPredial & rp) const;
};

class comandoAdImobiliaria: public Comando{
public:
    bool executa(std::istringstream &restoLinha, RegistoPredial & rp) const;
};
class comandoAnuncia: public Comando{
public:
    bool executa(std::istringstream &restoLinha, RegistoPredial & rp) const;
};
#endif //EX1__SMART_POINTES_COMANDO_H
