//
// Created by ASUS on 20/12/2023.
//
#include "Comando.h"
#include "FabricaObjetos.h"
using namespace std;
bool comandoAdImovel::executa(istringstream &restoLinha ,
                              RegistoPredial & rp) const {
    shared_ptr<Imovel> novo = FabricaObjetos::getImovel(
            restoLinha);
    bool resultado = false;
    if(novo != nullptr)
        resultado = rp.acrescenta(novo);//objeto �
    // duplicado dentro desta fun��o membro acrescenta
    //delete novo;
    return resultado;
}

bool comandoAdImobiliaria::executa(istringstream &restoLinha , RegistoPredial & rp) const {
    return rp.acrescenta(FabricaObjetos::getImobiliaria(restoLinha));
}

bool comandoAnuncia::executa(istringstream &restoLinha, RegistoPredial & rp) const {
    string codigo, nome;
    if(restoLinha >> codigo && restoLinha >> nome)
        return rp.anuncia(codigo, nome);

    return false;
}


std::string Comando::leComando(std::string &com) {
    string linha, restoLinha;
    cout << "---->";
    getline(cin, linha);
    istringstream is(linha);
    is >> com;
    getline(is, restoLinha);//what is remaining after extracting the first word
    return restoLinha;
}


Comando::Comando() {
    cout << "A construir comando que � apontado por um unique_ptr\n";
}
