//
// Created by ASUS on 20/12/2023.
//
#include "FabricaObjetos.h"
#include "Loja.h"
#include "Apartamento.h"
#include <iostream>

using namespace std;
const map<string, int> FabricaObjetos::comandos{
        {"sai", 0},
        {"adicImob", 1}, //adiciona imobiliaria com um dado nome
        {"adicImov", 2},//adciona um novo imovel:
        // adicImov <tipo: a|l> area
        //[andar_do_apartamento tipologia]
        {"list", 3}, //listar todo o Registo Predial
        {"anuncia", 4} //anuncia um dado imovel do Registo Predial numa
        // dada imobiliaria: anuncia codigo_imovel nome_imobiliaria
};


shared_ptr<Imovel> FabricaObjetos::getImovel(istream & is) {
    int andar, tipologia, area;
    char letra_tipo;
    if(is >> letra_tipo && is >> area){
        if(letra_tipo == 'a' && is >> andar &&
           is >> tipologia)
            return make_shared<Apartamento>(area, andar, tipologia);
        else if (letra_tipo == 'l')
            return make_shared<Loja>(area);
    }
    return nullptr;
}

Imobiliaria FabricaObjetos::getImobiliaria(std::istream &is) {
    string nome;
    if(is >> nome)
        return Imobiliaria(nome);
    else
        throw "Error creating imobiliaria";
}

unique_ptr<Comando> FabricaObjetos::getComando(const string & comando) {
    auto par = comandos.find(comando);
    if(par != comandos.end())
        switch(par->second){
            case 1:
                return make_unique<comandoAdImobiliaria>();

            case 2:
                return make_unique<comandoAdImovel>();

            case 4:
                return make_unique<comandoAnuncia>();
                break;
        }
    return {};
}