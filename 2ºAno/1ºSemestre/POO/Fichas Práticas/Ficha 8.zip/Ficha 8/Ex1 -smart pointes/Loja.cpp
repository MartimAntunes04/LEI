//
// Created by ASUS on 20/12/2023.
//
#include "Loja.h"
using namespace std;
Loja::Loja(int area): Imovel("loja", area, 15*area,0)
{
    std::cout << "A construir loja";
}
/*Loja::~Loja(){
    std::cout << "Destruir loja";
}*/
std::shared_ptr<Imovel>  Loja::duplica() const{
    return make_shared< Loja>(*this);
}