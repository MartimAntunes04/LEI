//
// Created by ASUS on 20/12/2023.
//

#ifndef EX1__SMART_POINTES_LOJA_H
#define EX1__SMART_POINTES_LOJA_H
#include "Imovel.h"

class Loja:public Imovel {
public:
    Loja(int area);
    //~Loja();
    virtual std::shared_ptr<Imovel> duplica() const;
};


#endif //EX1__SMART_POINTES_LOJA_H
