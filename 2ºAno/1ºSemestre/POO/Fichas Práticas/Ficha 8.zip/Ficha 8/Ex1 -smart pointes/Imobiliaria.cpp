//
// Created by ASUS on 20/12/2023.
//
#include "Imobiliaria.h"
using namespace std;
int Imobiliaria::pesquisa(const std::string & codigo) const {
    //retorna a posi��o (se existir) do im�vel
    // com aquele c�digo do vectgor, -1 se n�o
    int indice=-1;
    for(int i=0; i < imoveis.size(); i++)
        if(auto obj=imoveis.at(i).lock())
            if(obj->getCodigo() == codigo){
                indice = i;
                break;
            }
    return indice;
}

Imobiliaria::Imobiliaria(const std::string & nome):nome(nome){
    std::cout << "A construir imobiliaria";
}
Imobiliaria::~Imobiliaria(){std::cout << "Destruir imobiliaria";}
std::string Imobiliaria::obtemListaAndar(int andar){
    std::ostringstream os;
    for(auto el: imoveis)
        if(auto obj= el.lock())
            if(obj->getAndar() == andar)
                os << obj-> getAsString() << std::endl;
    return os.str();
}
const std::string &Imobiliaria::getNome() const {
    return nome;
}
bool Imobiliaria::remove(const std::string & codigo){
    int indice= pesquisa(codigo);
    if(indice != -1){
        imoveis.erase(imoveis.begin()+indice);
        return true;
    }
    return false;
}
bool Imobiliaria::acrescenta(weak_ptr<Imovel> im) {
    if (auto obj = im.lock())
        if(pesquisa( obj->getCodigo()) == -1) {
            imoveis.emplace_back(im);
            return true;
        }
    return false;
}
std::string Imobiliaria::obtemPorCodigo(std::string codigo){
    int indice= pesquisa(codigo);
    if (indice != -1)
        if(auto obj=imoveis.at(indice).lock())
            return obj->getAsString();
    return "";
}
std::string Imobiliaria::getAsString() const{
    std::ostringstream os;
    os << "Imobiliaria:" << nome << " com " <<
       imoveis.size() << "imoveis:\n";
    for(auto im: imoveis)
        if(auto obj = im.lock())
            os << obj->getAsString();
    return os.str();
}

void Imobiliaria::atualizaPonteiros(std::vector<std::shared_ptr<Imovel>> _imoveis){
    for(int i=0; i < imoveis.size(); i++)
        if(auto obj1 = imoveis.at(i).lock())
            for(int j= 0; j < _imoveis.size(); j++)
                if(obj1->getCodigo() == _imoveis.at(j)->getCodigo()) {
                    imoveis.at(i) = _imoveis.at(j);
                    break;
                }
}
