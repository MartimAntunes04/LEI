#include "RegistoPredial.h"
#include "Interacao.h"
using namespace std;

int main() {
    RegistoPredial rp ;
    Interacao inte(rp);
    inte.executa();
    RegistoPredial copia(rp);
    cout << "Original:" << rp.getAsString() << endl;
    cout << "Copia:" << copia.getAsString() << endl;
    /*vector<int> valores{1, 4, 2, 3};
   int tamanho = valores.size();
   for(auto it=valores.begin(); it != valores.end(); it++)
       if(*it % 2 == 0)
           valores.emplace_back((*it)/2);

   for(const int & elemento: valores)
       cout << " " << elemento;*/
    return 0;
}
