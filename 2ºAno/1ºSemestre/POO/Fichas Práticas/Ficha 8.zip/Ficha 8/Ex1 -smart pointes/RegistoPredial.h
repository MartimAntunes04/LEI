//
// Created by ASUS on 20/12/2023.
//

#ifndef EX1__SMART_POINTES_REGISTOPREDIAL_H
#define EX1__SMART_POINTES_REGISTOPREDIAL_H
#include "Imovel.h"
#include "Imobiliaria.h"
#include <vector>
#include <map>
#include <memory>
class RegistoPredial {
    std::vector<std::shared_ptr<Imovel>> imoveis;
    std::map<std::string,Imobiliaria> imobiliarias;
public:
    RegistoPredial(){} //Continuar a construir por omissão
    std::weak_ptr<Imovel> pesquisa(const std::string & cod );
    bool acrescenta(std::shared_ptr<Imovel> & im);
    bool acrescenta(Imobiliaria im);
    ~RegistoPredial();
    std::string getAsString() const;
    bool anuncia(const std::string & codigo_imovel,
                 const std::string & nome_imobiliaria);
    RegistoPredial(const RegistoPredial & outra);
    RegistoPredial & operator=(const RegistoPredial & outra);
};

#endif //EX1__SMART_POINTES_REGISTOPREDIAL_H
