//
// Created by Ana Oliveira Alves on 30/11/2023.
//

#include "RegistoPredial.h"
#include <sstream>

using namespace std;
bool RegistoPredial::acrescenta(Imovel *im){
    if(pesquisa(im->getCodigo()) == nullptr) {
        imoveis.emplace_back(im);
        return true;
    }
    return false;
}
RegistoPredial::~RegistoPredial(){
    for(Imovel *el: imoveis)
        delete el;
}

RegistoPredial::RegistoPredial(const RegistoPredial & outra) {
    *this=outra;
}

RegistoPredial &RegistoPredial::operator=(const RegistoPredial &outro){
    if(this!=&outro){
        for(auto e1:imoveis)
            delete e1;
        imoveis.clear();
        imobiliarias.clear();

        for(auto e1:outro.imoveis)
            imoveis.emplace_back(e1->Duplica());
        for(auto &e1:outro.imobiliarias)
            imobiliarias.insert(e1);
    }
    return *this;
}


Imovel * RegistoPredial::pesquisa(const std::string & cod ){
    for(int i=0; i < imoveis.size(); i++)
        if(imoveis.at(i)->getCodigo() == cod){
            return imoveis.at(i);
        }
    return nullptr;
}

bool RegistoPredial::acrescenta(Imobiliaria im) {
    if(imobiliarias.find(im.getNome()) == imobiliarias.end()) { //Não existe ainda
        imobiliarias.insert({im.getNome(),im});
        return true;
    }
    return false;
}

std::string RegistoPredial::getAsString() const {
    ostringstream os;
    os << "Registo Predial com " << imoveis.size() << " imoveis:\n";
    for(auto el: imoveis)
        os << el->getAsString() << endl;
    os << "----e com " << imobiliarias.size() << " imobiliarias:\n";
    for(const auto & el: imobiliarias)
        os << el.second.getAsString() << endl;
    return os.str();
}

bool RegistoPredial::anuncia(const std::string & codigo_imovel, const std::string & nome_imobiliaria){  //PROCESSADOR COM APARELHO
    auto el = imobiliarias.find(nome_imobiliaria);
    auto imov = pesquisa(codigo_imovel);
    if(el != imobiliarias.end() &&  imov != nullptr){
        return el->second.acrescenta(imov);
    }
    return false;
}