//
// Created by Ana Oliveira Alves on 06/12/2023.
//

#ifndef FICHA8_TURMAP6_EX1_INTERACAO_H
#define FICHA8_TURMAP6_EX1_INTERACAO_H
#include "RegistoPredial.h"


class Interacao{
    RegistoPredial *rp;
    static const std::map<std::string, int> comandos;
public:
    Interacao(RegistoPredial * r): rp(r){}
    void executa();
    std::string leComando( std::string & com);
    bool executaAdImovel(std::istringstream &restoLinha);
    bool executaAdImobiliaria(std::istringstream  & restoLinha);
    bool executaAnuncia(std::string  & restoLinha);
};


#endif //FICHA8_TURMAP6_EX1_INTERACAO_H
