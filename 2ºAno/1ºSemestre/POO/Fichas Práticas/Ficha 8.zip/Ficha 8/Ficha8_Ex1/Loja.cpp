//
// Created by aalve on 04/12/2023.
//

#include "Loja.h"
Loja::Loja(int area): Imovel("loja", area, 15*area,0)
{
    std::cout << "A construir loja";
}
Loja::~Loja(){
    std::cout << "Destruir loja";
}

Loja *Loja::Duplica() const {
    return new Loja(*this);
}