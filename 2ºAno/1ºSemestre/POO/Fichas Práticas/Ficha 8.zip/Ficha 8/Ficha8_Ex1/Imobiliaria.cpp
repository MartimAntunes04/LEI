//
// Created by aalve on 04/12/2023.
//

#include "Imobiliaria.h"
int Imobiliaria::pesquisa(const std::string & codigo) const {
    //retorna a posi��o (se existir) do im�vel
    // com aquele c�digo do vectgor, -1 se n�o
    int indice=-1;
    for(int i=0; i < imoveis.size(); i++)
        if(imoveis.at(i)->getCodigo() == codigo){
            indice = i;
            break;
        }
    return indice;
}

Imobiliaria::Imobiliaria(const std::string & nome):nome(nome){
    std::cout << "A construir imobiliaria";
}
Imobiliaria::~Imobiliaria(){std::cout << "Destruir imobiliaria";}
std::string Imobiliaria::obtemListaAndar(int andar){
    std::ostringstream os;
    for(auto el: imoveis)
        if(el->getAndar() == andar)
            os << el-> getAsString() << std::endl;
    return os.str();
}
const std::string &Imobiliaria::getNome() const {
    return nome;
}
bool Imobiliaria::remove(const std::string & codigo){
    int indice= pesquisa(codigo);
    if(indice != -1){
        imoveis.erase(imoveis.begin()+indice);
        return true;
    }
    return false;
}
bool Imobiliaria::acrescenta(Imovel *im) {
    if (pesquisa(im->getCodigo()) == -1) {
        imoveis.emplace_back(im);
        return true;
    }
    return false;
}
std::string Imobiliaria::obtemPorCodigo(std::string codigo){
    int indice= pesquisa(codigo);
    if (indice != -1)
        return imoveis.at(indice)->getAsString();
    return "";
}
std::string Imobiliaria::getAsString() const{
    std::ostringstream os;
    os << "Imobiliaria:" << nome << " com " <<
       imoveis.size() << "imoveis:\n";
    for(Imovel * im: imoveis)
        os << im->getAsString();
    return os.str();
}
