//
// Created by aalve on 04/12/2023.
//

#ifndef FICHA8_TURMAP6_EX1_IMOBILIARIA_H
#define FICHA8_TURMAP6_EX1_IMOBILIARIA_H
#include "Imovel.h"
#include <vector>

class Imobiliaria {
    std::vector<Imovel *> imoveis;
    std::string nome;

    int pesquisa(const std::string & codigo) const;
public:
    Imobiliaria(const std::string & nome);
    ~Imobiliaria();
    std::string obtemListaAndar(int andar);
    const std::string &getNome() const;
    bool remove(const std::string & codigo);
    bool acrescenta(Imovel *im);
    std::string obtemPorCodigo(std::string codigo);
    std::string getAsString() const;
};


#endif //FICHA8_TURMAP6_EX1_IMOBILIARIA_H
