//
// Created by aalve on 04/12/2023.
//

#ifndef FICHA8_TURMAP6_EX1_IMOVEL_H
#define FICHA8_TURMAP6_EX1_IMOVEL_H
#include <string>
#include <sstream>
#include <iostream>

class Imovel {
    int andar, area, preco;
    std::string codigo;
    static int contador;
public:
    Imovel(const std::string & tipo, int area, int preco, int andar);
    virtual ~Imovel();
    virtual Imovel *Duplica() const=0;
    virtual std::string getAsString() const;
    int getAndar()const;
    std::string getCodigo()const;
};
std::ostream & operator<<(std::ostream &o, const Imovel & im);



#endif //FICHA8_TURMAP6_EX1_IMOVEL_H
