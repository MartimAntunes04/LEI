//
// Created by aalve on 04/12/2023.
//


#include "RegistoPredial.h"
#include "Interacao.h"
using namespace std;

int main() {
    RegistoPredial rp;
    Interacao inte(&rp);
    inte.executa();
    RegistoPredial copia(rp);
    cout << "Original:" << rp.getAsString() << endl;
    cout << "Copia:" << copia.getAsString() << endl;
    RegistoPredial copia2;
    copia2 = rp;
    cout << "Original:" << rp.getAsString() << endl;
    cout << "Copia2:" << copia.getAsString() << endl;
    return 0;
}

