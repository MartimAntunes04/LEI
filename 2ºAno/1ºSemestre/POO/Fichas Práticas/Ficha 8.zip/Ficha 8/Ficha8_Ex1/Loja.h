//
// Created by aalve on 04/12/2023.
//

#ifndef FICHA8_TURMAP6_EX1_LOJA_H
#define FICHA8_TURMAP6_EX1_LOJA_H
#include "Imovel.h"

class Loja:public Imovel {
public:
    Loja(int area);
    ~Loja();
    Loja *Duplica()const override;
};






#endif //FICHA8_TURMAP6_EX1_LOJA_H
