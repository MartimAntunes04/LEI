//
// Created by Ana Oliveira Alves on 06/12/2023.
//

#include "Interacao.h"
#include "Apartamento.h"
#include "Loja.h"
using namespace std;
const map<string, int> Interacao::comandos{
        {"sai", 0},
        {"adicImob", 1}, //adiciona imobiliaria com um dado nome
        {"adicImov", 2},//adciona um novo imovel: adicImov <tipo: a|l> area
        //[andar_do_apartamento tipologia]
        {"list", 3}, //listar todo o Registo Predial
        {"anuncia", 4} //anuncia um dado imovel do Registo Predial numa
        // dada imobiliaria: anuncia codigo_imovel nome_imobiliaria
};
void Interacao::executa() {
    string comando, restoLinha;
    istringstream is;
    do {
        restoLinha = leComando(comando);
        istringstream is(restoLinha);
        auto opcao = comandos.find(comando);
        if (opcao != comandos.end()) {
            cout << "comando " << opcao->first << endl;
            switch (opcao->second) {
                case 1:
                    if(executaAdImobiliaria(is))
                        cout << "Comando executado com sucesso\n";
                    break;
                case 2:
                    if(executaAdImovel(is))
                        cout << "Comando executado com sucesso\n";
                    break;
                case 3:
                    cout << rp->getAsString();
                    break;
                case 4:
                    if(executaAnuncia(restoLinha))
                        cout << "Comando executado com sucesso\n";
                    break;
            }
        } else
            cout << "comando invalido ou ainda não implementado\n";
    }while(comando != "sai");
}

std::string Interacao::leComando(std::string &com) {
    string linha, restoLinha;
    cout << "---->";
    getline(cin, linha);
    istringstream is(linha);
    is >> com;
    getline(is, restoLinha);//what is remaining after extracting the first word
    return restoLinha;
}

bool Interacao::executaAdImovel(std::istringstream &restoLinha) {
    int andar, tipologia, area;
    char letra_tipo;
    if(restoLinha >> letra_tipo && restoLinha >> area){
        if(letra_tipo == 'a' && restoLinha >> andar && restoLinha >> tipologia)
            return rp->acrescenta(new Apartamento(area, andar, tipologia));
        else if (letra_tipo == 'l')
            return rp->acrescenta(new Loja(area));
    }
    return false;
}

bool Interacao::executaAdImobiliaria(std::istringstream &restoLinha) {
    string nome;
    if(restoLinha >> nome)
        return rp->acrescenta(Imobiliaria(nome));
    return false;
}

bool Interacao::executaAnuncia(string &restoLinha) {
    string codigo, nome;
    istringstream is(restoLinha);
    if(is >> codigo && is >> nome){
        return rp->anuncia(codigo, nome);
    }
    return false;
}


