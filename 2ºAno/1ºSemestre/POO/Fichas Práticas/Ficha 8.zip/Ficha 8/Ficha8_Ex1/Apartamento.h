//
// Created by aalve on 04/12/2023.
//

#ifndef FICHA8_TURMAP6_EX1_APARTAMENTO_H
#define FICHA8_TURMAP6_EX1_APARTAMENTO_H
#include "Imovel.h"

class Apartamento:public Imovel {
    int n_assoalhadas;
public:
    Apartamento(int area, int andar,int n_a);
    ~Apartamento();
    std::string getAsString();
     Apartamento *Duplica()const override;
};


#endif //FICHA8_TURMAP6_EX1_APARTAMENTO_H
