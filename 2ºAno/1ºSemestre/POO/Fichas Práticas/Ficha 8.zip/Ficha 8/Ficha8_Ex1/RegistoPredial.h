//
// Created by Ana Oliveira Alves on 30/11/2023.
//

#ifndef FICHA7_TURMAP4_EX1_REGISTOPREDIAL_H
#define FICHA7_TURMAP4_EX1_REGISTOPREDIAL_H
#include "Imovel.h"
#include "Imobiliaria.h"
#include <vector>
#include <map>
class RegistoPredial {
    std::vector<Imovel *> imoveis;
    std::map<std::string,Imobiliaria> imobiliarias;
public:
    Imovel * pesquisa(const std::string & cod );
    RegistoPredial()=default;
    RegistoPredial(const RegistoPredial & outra);
    RegistoPredial &operator=(const RegistoPredial &outro);
    bool acrescenta(Imovel *im);
    bool acrescenta(Imobiliaria im);
    ~RegistoPredial();
    std::string getAsString() const;
    bool anuncia(const std::string & codigo_imovel, const std::string & nome_imobiliaria);
};


#endif //FICHA7_TURMAP4_EX1_REGISTOPREDIAL_H
