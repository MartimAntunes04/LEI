//
// Created by ASUS on 06/12/2023.
//

#ifndef EX1_IMOVEL_H
#define EX1_IMOVEL_H
#include <string>
#include <sstream>
#include <iostream>

class Imovel {
    int andar, area, preco;
    std::string codigo;
    static int contador;
public:
    Imovel(const std::string & tipo, int area, int preco, int andar): preco(preco), area(area), andar(andar) {
        std::ostringstream os;
        os << tipo << ++contador;
        codigo = os.str();
        std::cout << "A contruir imovel";
    }
    virtual ~Imovel(){ //Tambem o da derivada será chamado
        std::cout << "A destruir imovel";
    }
    virtual std::string getAsString() const{
        std::ostringstream os;
        os << "Imovel:" << codigo << " "
           <<  area << "m2 " << preco  << "? "
           << andar << "º andar ";
        return os.str();
    }
    int getAndar()const{
        return andar;
    }
    std::string getCodigo()const{
        return codigo;
    }


};

std::ostream & operator<<(std::ostream &o, const Imovel & im);
#endif //EX1_IMOVEL_H
