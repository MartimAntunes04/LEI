//
// Created by ASUS on 06/12/2023.
//
#include "Imovel.h"
int Imovel::contador = 0;

std::ostream & operator<<(std::ostream &o, const Imovel & im){
    o << im.getAsString();
    return o;
}