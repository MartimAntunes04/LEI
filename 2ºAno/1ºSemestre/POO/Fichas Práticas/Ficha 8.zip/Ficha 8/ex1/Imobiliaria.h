//
// Created by ASUS on 06/12/2023.
//

#ifndef EX1_IMOBILIARIA_H
#define EX1_IMOBILIARIA_H
#include "Imovel.h"
#include <vector>

class Imobiliaria {
    std::vector<Imovel *> imoveis;
    std::string nome;
    int pesquisa(const std::string & codigo) const {
        //retorna a posição (se existir) do imóvel
        // com aquele código do vectgor, -1 se não
        int indice=-1;
        for(int i=0; i < imoveis.size(); i++)
            if(imoveis.at(i)->getCodigo() == codigo){
                indice = i;
                break;
            }
        return indice;
    }
public:
    Imobiliaria(const std::string & nome):nome(nome){
        std::cout << "A construir imobiliaria";
    }
    ~Imobiliaria(){std::cout << "Destruir imobiliaria";}
    std::string obtemListaAndar(int andar){
        std::ostringstream os;
        for(auto el: imoveis)
            if(el->getAndar() == andar)
                os << el-> getAsString() << std::endl;
        return os.str();
    }
    bool remove(const std::string & codigo){
        int indice= pesquisa(codigo);
        if(indice != -1){
            imoveis.erase(imoveis.begin()+indice);
            return true;
        }
        return false;
    }
    bool acrescenta(Imovel *im) {
        if (pesquisa(im->getCodigo()) == -1) {
            imoveis.emplace_back(im);
            return true;
        }
        return false;
    }
    std::string obtemPorCodigo(std::string codigo){
        int indice= pesquisa(codigo);
        if (indice != -1)
            return imoveis.at(indice)->getAsString();
        return "";
    }
    std::string getAsString() const{
        std::ostringstream os;
        os << "Imobiliaria:" << nome << " com " <<
           imoveis.size() << "imoveis:\n";
        for(Imovel * im: imoveis)
            os << im->getAsString();
        return os.str();
    }

};
#endif //EX1_IMOBILIARIA_H
