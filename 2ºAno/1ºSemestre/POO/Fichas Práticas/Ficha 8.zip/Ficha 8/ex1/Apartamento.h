//
// Created by ASUS on 06/12/2023.
//

#ifndef EX1_APARTAMENTO_H
#define EX1_APARTAMENTO_H
#include "Imovel.h"

class Apartamento:public Imovel {
    int n_assoalhadas;
public:
    Apartamento(int area, int andar,int n_a):
            Imovel("apartamento",area, area*10, andar){
        this->n_assoalhadas= n_a;
        std::cout << "A construir apartamento";
    }
    ~Apartamento(){
        std::cout << "A destruir apartamento";
    }
    std::string getAsString() const{
        std::ostringstream os;
        os << "T" << n_assoalhadas <<
           Imovel::getAsString();
        return os.str();
    }
};
#endif //EX1_APARTAMENTO_H
