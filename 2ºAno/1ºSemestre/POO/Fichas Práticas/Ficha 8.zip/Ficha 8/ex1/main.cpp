#include "Imobiliaria.h"
#include "Imovel.h"
#include "Apartamento.h"
#include "Loja.h"
#include <iostream>
using namespace std;

int main(){
    Imobiliaria imob1("Remax");
    std::cout << "É permitido fazer sobre a imobiliária:"
              << " acrescentar bens imobiliários do edifício\n"
              <<   " fazer listagens de bens imobiliários por andar\n"
              <<  " e pesquisa por código\n"
              << " obter os preços e descrição \n"
              << "remover por código";
    Loja im1(100);
    Apartamento im2(200, 1, 2); //1º andar e T2
    Imovel *im_dinamico = new Loja(200);
    imob1.acrescenta(&im1);
    imob1.acrescenta(&im2);
    cout << imob1.obtemListaAndar(1);
    cout << imob1.obtemPorCodigo("loja1");
    cout << imob1.getAsString(); //Listagem de tudo
    imob1.remove("loja1");
    cout << imob1.getAsString(); //Listagem de tudo
    delete im_dinamico;
    return 0;
}

