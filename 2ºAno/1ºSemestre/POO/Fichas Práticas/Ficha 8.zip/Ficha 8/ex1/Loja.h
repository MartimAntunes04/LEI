//
// Created by ASUS on 06/12/2023.
//

#ifndef EX1_LOJA_H
#define EX1_LOJA_H
#include "Imovel.h"

class Loja:public Imovel {
public:
    Loja(int area): Imovel("loja", area, 15*area,0)
    {
        std::cout << "A construir loja";
    }
    ~Loja(){
        std::cout << "Destruir loja";
    }
};

#endif //EX1_LOJA_H
