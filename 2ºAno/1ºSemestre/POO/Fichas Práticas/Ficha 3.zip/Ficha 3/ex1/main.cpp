#include <iostream>
#include <sstream>
#include <span>
using namespace std;
class Tabela{
public:
    void fill(int valor);
    void listar ();
    void altera(int posicao,int valor);
private:

    static const int nnumeros=15;
    int numeros[nnumeros];
    int valores;

};

void Tabela::fill(int valor){
    for(int i=0;i<nnumeros;i++){
        numeros[i]=valor;
    }
}
void Tabela::listar(){
    for(int i=0;i<nnumeros;i++){
        cout << "Valores: " << numeros[i] << endl;
    }
};

void Tabela::altera(int posicao,int valor){

    if(posicao>=0 && posicao<nnumeros){
        numeros[posicao]=valor;
    }
    else{
        throw invalid_argument("Posicao invalida");
    }
}




int main() {

    Tabela tab1;
    tab1.fill(2);
    tab1.altera(1,10);
    tab1.listar();
    return 0;
}
