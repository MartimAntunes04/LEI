//
// Created by ASUS on 29/10/2023.
//

#ifndef EX2_AUTO_H
#define EX2_AUTO_H
#include <string>
using namespace std;
class Auto{
    std::string matricula;
    std::string marca;
    std::string modelo;
    int ano;

public:
    Auto(std::string nMarca,string nModelo,int nAno,string Matricula);



    string getMat()const{
            return matricula;
    }

    string getMarca()const{
        return marca;
    }

    int getAno()const{
        return ano;
    };

    string getModelo()const{
        return modelo;
    }

    void setMat(string newMat) ;
};




#endif //EX2_AUTO_H
