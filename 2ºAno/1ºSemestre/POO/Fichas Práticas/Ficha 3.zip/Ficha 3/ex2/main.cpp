#include <iostream>
#include "Auto.h"
int main() {
    Auto c1("Audi","A4",2004,"48-25-XX");
    Auto c2("Porshe"," 911 Careira S",2023,"07-AB-98");
    cout<<c1.getMat()<<endl;

    c1.setMat("48-56-BI");

    cout << c2.getModelo()<< endl;
    return 0;
}
