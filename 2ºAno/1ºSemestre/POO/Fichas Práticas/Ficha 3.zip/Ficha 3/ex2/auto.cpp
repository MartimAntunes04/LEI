//
// Created by ASUS on 29/10/2023.
//
#include "auto.h"
#include <cstring>
#include <string>

#include <iostream>
using namespace std;
Auto::Auto(string nMarca,string nModelo,int nAno,string Matricula) {
    marca = nMarca;
    modelo = nModelo;
    ano = nAno;
    matricula = Matricula;

}

void Auto::setMat(string newMat) {
    matricula = newMat;
}
