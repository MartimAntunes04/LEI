#include <iostream>
#include <string>
#include "pessoa.h"
using namespace std;
int main() {
    Pessoa p1("Martim",19,"Masculino","Serta");

    cout << p1.getnome() << " tem " << p1.getidade() << " do sexo " << p1.getxexo() << " e mora em " << p1.getmorada();
    return 0;
}
