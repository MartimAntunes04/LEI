//
// Created by ASUS on 29/10/2023.
//
#include "pessoa.h"
#include <string>
#include <iostream>

Pessoa::Pessoa(string name, int nidade, string nsexo, string nmorada) {
    nome=name;
    idade= nidade;
    sexo=nsexo;
    morada=nmorada;
}

