//
// Created by ASUS on 29/10/2023.
//
#include <iostream>
#ifndef EX3_PESSOA_H
#define EX3_PESSOA_H
using namespace std;
class Pessoa{
    std::string sexo;
    std::string nome;
    int idade;
    std::string morada;
public:
    Pessoa(string name,int nidade,string nsexo,string nmorada);

    string getnome(){
        return nome;
    }
    int getidade()const{
        return idade;
    }
    string getxexo(){
        return sexo;
    }
    string getmorada(){
        return morada;
    }
};



#endif //EX3_PESSOA_H
