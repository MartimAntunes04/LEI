//
// Created by ASUS on 30/10/2023.
//
#include "letra.h"
#include <iostream>
#include <string>
using namespace std;
Letra::Letra(string letras,int numero){
    letra=letras="x";
    num=numero;
    cout << "Constrindo objeto.... letra: "  << letras << "  numero: " << numero;
}
Letra::~Letra() {
    cout<< "\nTerminado: letra:  " << letra << "  numero: "<< num;
}