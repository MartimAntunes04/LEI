//
// Created by ASUS on 30/10/2023.
//

#ifndef EX4_LETRA_H
#define EX4_LETRA_H
#include <iostream>
using namespace std;
class Letra{
    string letra;
    int num;

public:
    Letra(string letras="x",int numero=1);
    ~Letra();
};



#endif //EX4_LETRA_H
