//
// Created by ASUS on 20/12/2023.
//
#include "MyString.h"
#include <iostream>
#include <cstring>

using namespace std;
MyString::MyString(){
    /*p = nullptr;*/
    tam = 0;
    cout << "construtor por omissao (nullptr)\n";
};
MyString::MyString(const char *p){
    tam = strlen(p);
    this->p = make_unique<char[]>(tam+1);
    for(int i=0; i < tam; i++)
        this->p[i]=p[i];

    cout << "construtor " << this->p << endl;
}
/*MyString::~MyString(){
    cout << "destrutor " << p << endl;
    delete []p;
}*/
/*int MyString::getTam() const {
    return tam;
}*/

const char * MyString::getMyString() const{
    return p.get();
}

char & MyString::at(int index){
    if(index < 0 || index >= tam )
        throw "Index out of bounds!";
    return p[index];
}

void MyString::concat(const MyString &other) {
    unique_ptr<char[]> newp = make_unique<char[]>(tam + other.tam + 1);
    int i;
    for(i=0; i < tam; i++)
        newp[i]=p[i];
    for(int j=0; j < other.tam; j++,i++)
        newp[i]=other.p[j];
    tam += other.tam;
    p=std::move(newp);
}

void MyString::clear() {
    p=unique_ptr<char[]>(0);
    tam = 0;
}

MyString::MyString(const MyString & other){
    *this = other;
}
MyString & MyString::operator=(const MyString & other){
    if(this != &other){
        tam = other.tam;
        unique_ptr<char[]> novop=  make_unique<char[]>(tam);
        for(int i=0; i < tam; i++)
            novop[i]=other.p[i];
        this->p = std::move(novop);
    }
    return *this;
}
