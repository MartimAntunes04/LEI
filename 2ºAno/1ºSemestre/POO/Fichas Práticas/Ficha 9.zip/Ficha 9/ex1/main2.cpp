//
// Created by ASUS on 20/12/2023.
//

#include "MyString.h"
#include "iostream"
#include "sstream"
using namespace std;
int main(){

    MyString m1("ola");
    cout << m1.at(2) << endl;
    cout << m1.getMyString() << endl;
    MyString m2(m1);
    MyString m3;
    m3=m1;
    cout << m3.getMyString();
    m1.concat(m2);
    cout << m1.getMyString();
    return 0;


}