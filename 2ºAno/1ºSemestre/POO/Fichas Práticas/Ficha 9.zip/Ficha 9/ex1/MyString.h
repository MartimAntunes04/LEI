//
// Created by ASUS on 20/12/2023.
//

#ifndef EX1_MYSTRING_H
#define EX1_MYSTRING_H
#include "memory";
using namespace std;

class MyString{
    unique_ptr<char []>p;
    int tam;
public:
    MyString();
    MyString(const char *p);

    int getTam()const{
        return tam;
    }
    const char * getMyString()const;
    char & at(int index);
    void concat(const MyString & other);
    void clear();
    //robustez a copiar
    MyString(const MyString &other);
    MyString & operator=(const MyString & other);
};


#endif //EX1_MYSTRING_H
