//
// Created by ASUS on 20/12/2023.
//
// includes e outras declarações omitidos
#include "Ponto.h"
#include <istream>
#include "iostream"
using namespace std;
Ponto::Ponto(int cx, int cy) : x(cx), y(cy) { cout << "CONSTR. "; mostra(); }
Ponto::~Ponto(){ cout << "DESTR. "; mostra(); }
void Ponto:: mostra() const { cout << "Ponto com " << x << "," << y << "\n"; }