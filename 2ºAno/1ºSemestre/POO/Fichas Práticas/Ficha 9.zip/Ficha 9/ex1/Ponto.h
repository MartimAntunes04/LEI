//
// Created by ASUS on 20/12/2023.
//

#ifndef EX1_PONTO_H
#define EX1_PONTO_H
// includes e outras declarações omitidos
class Ponto {
public:
    Ponto(int cx=0, int cy=0);
    ~Ponto();
    void mostra() const;
private:
    int x,y;
};

#endif //EX1_PONTO_H
