#include <iostream>
#include "Ponto.h"
#include "memory"
using namespace std;
int main() {

    weak_ptr<Ponto> spw;
    shared_ptr<Ponto> sps2; //Para que objeto este shared estaria a apontar
    if(spw.expired())
        cout << "ponteiro nao esta valido";
    // zona inicial
    {// bloco B1
        unique_ptr<Ponto> spu = make_unique<Ponto>(1, 1);
        //spw=spu; //NAO É POSSIVEL ASSOCIAR UM WEAK_PTR

         spu->mostra();

    }
    cin.get();
    {// bloco B2
        shared_ptr<Ponto> sps1 = make_unique<Ponto>(2, 2);
        sps1->mostra();
        spw = sps1;
        cout << sps2.use_count() << endl;  //quantos shared_ptrs estao a apontar pars aquilo que sps2 esta a apontar

        if(sps2 == nullptr)
            cout << "este shared_ptr nao esta a apontar para nada\n";

        sps2 = sps1;  //este objeto vai sobreviver apos este bloco pois o shared
                      // pq o outro shared_ptr ainda existe
        cout << sps1.use_count();
        if (auto obj = spw.lock())
            obj->mostra();
        cout << "Antes de acabar o bloco 2\n";
    }
    cin.get();
    {// bloco B3
    cout << "Ja no bloco 3\n";


    }

    unique_ptr<Ponto[]>arrayu = make_unique<Ponto[]>(10);
    //shared_ptr <Ponto[]> arrays = make_shared<Ponto[]>(10);
    weak_ptr<Ponto[]> arrayw;
    //arrayw = arrays;
    if(auto obj = arrayw.lock())
        for(int i=0;i<10;i++){
            cout << "weak: ";
            obj[i].mostra();
        }





    return 0;
}
