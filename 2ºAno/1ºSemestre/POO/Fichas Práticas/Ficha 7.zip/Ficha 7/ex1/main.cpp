#include <iostream>
#include "ponto.h"
#include "sstream"
#include "iostream"
using namespace std;

int main() {
    int n=3,l=2,c=3;
    Ponto *a=new Ponto(1,2);
    Ponto *b= nullptr;
    b=new Ponto (3,4);



    //Ponto *array_uni=new Ponto[n];


    Ponto ***matriz=new Ponto **[l];
    for(int i=0;i<l;i++){
        matriz[i]=new Ponto*[c];
    }

    cout << "fim da construcao da matriz\n";

    for(int i=0;i<l;i++)
        for(int j=0;j<c;j++)
            matriz[i][j]= nullptr;


    matriz[1][1]=new Ponto(9,9);
    matriz[0][1]=new Ponto (8,8);


    for(int i=0;i<l;i++){
        for(int j=0;j<c;j++)
            if(matriz[i][j]!= nullptr)
                cout << matriz[i][j]->getX();
            else
                cout << '*';
            cout << endl;

    }
    for(int i=0;i<l;i++){
        for(int j=0;j<c;j++)
            delete matriz[i][j];
        delete[]matriz[i];

    }
    delete[]matriz;



    //delete[]array_uni;

    delete a;
    delete b;

    cout << "\nfinal";
    return 0;
}
