//
// Created by ASUS on 22/11/2023.
//

#include "ponto.h"
#include <iostream>
#include <sstream>
using namespace std;

// includes e outras declarações omitidos
Ponto::Ponto(int cx, int cy) : x(cx), y(cy) {
    cout << "CONSTR. Ponto com " << x << "," << y << "\n";
}


Ponto::~Ponto(){
    cout << "DESTR. Ponto com " << x << "," << y << "\n";
}
int Ponto::getX() const {
    return x;
}

int Ponto::getY() const {
    return y;
}

