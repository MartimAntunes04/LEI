#include <iostream>
#include "RegistoCivil.h"
#include "ClubeB.h"
#include "Rico.h"
using namespace std;
int main() {
    RegistoCivil r1("Portugal");
    cout << r1.getAsString() << endl;
    r1.registaDoFicheiro("pessoas.txt");
    cout << endl << r1.getAsString();
    while(cin.get()!='\n');
    ClubeB aac("AAC", "Associacão Académica de Coimbra");
    aac.inscreve(r1.getPessoa(5678));
    ClubeB slb("SLB", "Sport Lisboa e Benfica");
    slb.inscreve(r1.getPessoa(5678));
    r1.regista(new Rico(10000,1239, 1239, "Antonio"));

    r1.atualizaNome(5678, "Pedro Silva");
    cout << r1.getAsString() << endl;
    aac.inscreve(r1.getPessoa(1239));
    cout << endl << aac.getAsString() <<endl << slb.getAsString();
    while(cin.get()!='\n');
    /*Problema - qual versão será robusta (por enquanto) caso a pessoa
    deixe de existir?*/
    //r1.apaga(5678); //Ainda não conseguimos
    cout << endl << aac.getAsString();cout << endl << slb.getAsString();
    while(cin.get()!='\n');

    ClubeB copia(aac);
    ClubeB novoc("Uniao","Uniao 1919");
    novoc = aac;

    //Registo Civil- é seguro copiar pelo C++
    RegistoCivil copiar(r1);
    RegistoCivil novor("Espanha");
    novor = r1;


    cout << "adeus\n";


    return 0;}
