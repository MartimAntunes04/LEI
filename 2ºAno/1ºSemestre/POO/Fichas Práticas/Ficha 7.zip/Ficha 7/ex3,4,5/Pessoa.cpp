//
// Created by ASUS on 29/11/2023.
//
#include "Pessoa.h"
#include <iostream>
#include <sstream>
using namespace std;

Pessoa::Pessoa(long id, long nif, const string & n):nome(n),id(id), nif(nif){
    cout << "A construir pessoa " << nome;
}
int Pessoa::getId() const{
    return id;
}
string Pessoa::getAsString()const{
    ostringstream os;
    os << "Pessoa:" << nome << "\tId:" << id  << "\tNif:" << nif << endl;
    return os.str();
}

Pessoa::~Pessoa(){
    cout << "A destruir pessoa " << nome;
}

void Pessoa::setNome(const string & n)
{
    nome = n;
}

const string &Pessoa::getNome() const {
    return nome;
}
