//
// Created by ASUS on 29/11/2023.
//

#ifndef EX3_4_5_PESSOA_H
#define EX3_4_5_PESSOA_H

#include <string>


class Pessoa{
    std::string nome;
    long id, nif;

public:
    const std::string &getNome() const;
    Pessoa(long id=0, long nif=0, const std::string & n="vazio");
    int getId() const;
    virtual std::string getAsString()const;
    ~Pessoa();
    void setNome(const std::string & n);
};

#endif //EX3_4_5_PESSOA_H
