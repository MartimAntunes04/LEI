//
// Created by ASUS on 29/11/2023.
//

#ifndef EX3_4_5_RICO_H
#define EX3_4_5_RICO_H
#include "Pessoa.h"

class Rico:public Pessoa{
    float patrimonio;
public:
    Rico(float patrimonio,long id,long nif,const std::string &nome);
    std::string getAsString()const;
};
#endif //EX3_4_5_RICO_H
