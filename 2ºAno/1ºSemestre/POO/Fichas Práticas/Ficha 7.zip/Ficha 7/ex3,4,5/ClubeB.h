//
// Created by ASUS on 29/11/2023.
//

#ifndef EX3_4_5_CLUBEB_H
#define EX3_4_5_CLUBEB_H
#include "Pessoa.h"
#include "Pessoa.h"
#include <map>
class ClubeB {
    std::string nome, descricao;
    std::map<long,Pessoa*> pessoas;
    //substituir por vector<Pessoa *> pessoas;
   /* static const int max = 50;
    Pessoa * pessoas[max];
    int total;*/
public:
    ClubeB(const std::string & n, const std::string & d);
    ~ClubeB();
    bool verifica(long id)const;
    bool inscreve(Pessoa * p);
    std::string getAsString()const;

};
#endif //EX3_4_5_CLUBEB_H
