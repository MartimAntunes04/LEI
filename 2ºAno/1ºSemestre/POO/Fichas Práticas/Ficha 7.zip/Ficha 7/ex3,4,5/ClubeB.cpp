    //
// Created by ASUS on 29/11/2023.
//
#include "ClubeB.h"
#include <iostream>
#include <sstream>
#include <map>
using namespace std;

ClubeB::ClubeB(const std::string & n, const std::string & d):
        nome(n), descricao(d){
    //Agora o vector está vazio no início
    /*for(int i=0; i< max; i++)
        pessoas[i] = nullptr;

    total = 0;*/
    cout << "Construir clube " << nome;
}
ClubeB::~ClubeB(){
    cout << "Destruir clube " << nome;
}

bool ClubeB::verifica(long search_id) const {
    auto p=pessoas.find(search_id);
    if(p!= pessoas.end()){
        return  true;
    }

    /*for(auto p: pessoas){
        if (p. != nullptr && p->getId())
            return true;
    }
     */
    return false;
}

bool ClubeB::inscreve(Pessoa * p)  {
    //Se for já socia
    if(verifica(p->getId()))
        return false;
    //lembrar que é apenas para emplace_back(&p);

    pessoas.insert({p->getId(),p});
    return true;
    /*for(int i=0; i < max; i++)
        if(pessoas[i] == nullptr) {
            pessoas[i] = &p;
            total++;
            return true;
        }


    return false; //Se não saiu pelo return true */
}
std::string ClubeB::getAsString()const{
    ostringstream os;
    os << "Clube com " << pessoas.size() << " socios\n";
    for(auto p:pessoas)
        if (p.second) //Não é nullptr
            os << p.second->getNome() << '\t';
    os << endl;
    return os.str();
}
