//
// Created by ASUS on 29/11/2023.
//
#include "Rico.h"
#include "Pessoa.h"
#include <ostream>
#include <sstream>
using namespace std;
Rico::Rico(float patrimonio, long id, long nif, const std::string &nome) : Pessoa(id,nif,nome){
    this->patrimonio=patrimonio;
}

string Rico:: getAsString()const{
    ostringstream os;
    os << "Patrimonio: " << patrimonio << Pessoa::getAsString();
    return os.str();
}