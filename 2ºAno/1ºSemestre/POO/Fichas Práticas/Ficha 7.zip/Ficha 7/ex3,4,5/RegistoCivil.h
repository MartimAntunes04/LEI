//
// Created by ASUS on 29/11/2023.
//

#ifndef EX3_4_5_REGISTOCIVIL_H
#define EX3_4_5_REGISTOCIVIL_H
#include "Pessoa.h"
#include <vector>

class RegistoCivil {
    /*** Passar para coleção objetos
    //dinâmicos - vector<Pessoa *>**/
    std::string pais;
    std::vector<Pessoa*>fichas;
    /*static const int max = 50;
    Pessoa fichas[max];
    int total;
    */
    int verifica(long id) const;

public:
    RegistoCivil(const RegistoCivil & outro);
    int getTotal() const;
    RegistoCivil(const std::string & n); //Coleção vazia no construtor
    ~RegistoCivil(); //Melhorar este destrutor
    std::string getAsString()const;
    std::string getPais() const;
    bool regista(long id, long nif, const std::string & n);
    bool regista(Pessoa *p);
    void registaDoFicheiro(const std::string & ficheiro);
    std::string getPessoaNome(long id)const;
    bool apaga(long id);
    bool atualizaNome(long id, const std::string &n);
    Pessoa * getPessoa(long id);
    RegistoCivil & operator=(const RegistoCivil &outro);
};
#endif //EX3_4_5_REGISTOCIVIL_H
