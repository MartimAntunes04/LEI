//
// Created by ASUS on 29/11/2023.
//
#include "RegistoCivil.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include "Pessoa.h"
using namespace std;

RegistoCivil::RegistoCivil(const std::string &n): pais(n) {
    cout << "A construir Registo Civil " << pais;
}
RegistoCivil::~RegistoCivil(){
    /*** Precisar libertar objetos de dentro do vector**/
    cout << "A destruir Registo Civil " << pais;
    for(auto it = fichas.begin();it !=fichas.end();it++)
        delete *it;
}

std::string RegistoCivil::getAsString() const {
    ostringstream os;

    /*** Lembrar que fichas.size() tem sempre o nº de elementos atualizados**/
    os << "Registo Civil " << pais << " com os " << fichas.size() << " registos:\n";
    for(auto it=fichas.begin();it!=fichas.end();it++){
        /*** Chamar sobre cada pessoa a função ->getId**/
        if ((*it)->getId() != 0)
            os << (*it)->getAsString();
        }
    return os.str();
}

std::string RegistoCivil::getPais() const{
    return pais;
}

bool RegistoCivil::regista(long id, long nif, const string & n){
    /*** //novo objeto dinâmico acrescentado no vector
              fichas.emplace_back(new Pessoa(id, nif, n)); **/
   if(verifica(id) == -1 ){

       fichas.emplace_back(new Pessoa(id,nif,n));
       return true;

       /* for(int i=0; i < max; i++)//encontrar uma posição vaga
            if(fichas[i].getId()==0){
                fichas[i]=Pessoa(id, nif, n );

                total++;
                return true;
            }
        //Se não encontrou uma vaga é porque está cheio*/
    }
    return false;
}

Pessoa * RegistoCivil::getPessoa(long id){
    //Se não encontrar retorna nullptr
    int indice = verifica(id);
    if(indice != -1)
        /*** Nesta posição, se existir, já é um ponteiro**/
        return fichas.at(indice);
    return nullptr;
}

int RegistoCivil::verifica(long id) const{//Se existir retorna o índice , se não é -1
    int indice= -1;
    for(int i=0; i < fichas.size(); i++)
/*** /->getId**/
        if (fichas.at(i)->getId() == id) {
            indice = i; //verifica se já está registado
            break;
        }
    return indice;
}

void RegistoCivil::registaDoFicheiro(const string & ficheiro){
    ifstream fich(ficheiro);
    if(fich){ //ficheiro encontrado e aberto
        string linha, parte;
        int nif, id;
        while(getline(fich, linha)){
            istringstream is(linha);
            if(is >> parte && is >> nif && is >> id){
                regista(id, nif, parte);
            }
        }
    }
}

bool RegistoCivil::apaga(long id){
/***
    //delete pessoa
//apagar esta pessoa do vector**/
    int indice;
    if((indice = verifica(id)) == -1)
        return false;
    /*fichas[indice]=Pessoa();
    total--;*/
    delete fichas.at(indice);
    fichas.erase(fichas.begin()+indice);
    return true;
}

string RegistoCivil::getPessoaNome(long id) const {
    int indice;
    if((indice= verifica(id))!=-1)
/*** //->getNome**/
        return fichas.at(indice)->getNome();
    return "Não encontrado";
}

bool RegistoCivil::atualizaNome(long id, const string &n){
    int indice;
    if((indice= verifica(id))!=-1) {
/*** ->setNome*/
        fichas.at(indice)->setNome(n);
        return true;
    }
    return false;
}

int RegistoCivil::getTotal() const {
/*** //return fichas.size()**/
    return fichas.size();
}

bool RegistoCivil::regista(Pessoa *p) { //o objeto ja criado
    if(verifica(p->getId()) == -1 ){

        fichas.emplace_back(p);
        return true;

    }
    return false;
}

//Fazer isto visto registo civil ser composicao
RegistoCivil::RegistoCivil(const RegistoCivil & outro){
    //criar novas copias das pessoas que estao no outro registo civil
    for(Pessoa *p : outro.fichas)
        fichas.emplace_back(new Pessoa(*p));

    pais=outro.pais;
    cout << "Construtor por copia Registo Civil\n";
}

RegistoCivil &RegistoCivil::operator=(const RegistoCivil &outro) {
    for(auto it = fichas.begin();it !=fichas.end();it++)
        delete *it;

    fichas.clear();
    //criar novas copias das pessoas que estao no outro registo civil
    for(Pessoa *p : outro.fichas)
        fichas.emplace_back(new Pessoa(*p));

    pais=outro.pais;
    std::cout << "Operador atribuicao Registo Civil\n";
    return *this;

}