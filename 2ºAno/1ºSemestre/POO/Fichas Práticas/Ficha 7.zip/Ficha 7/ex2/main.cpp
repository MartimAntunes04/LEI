#include <iostream>
#include "string.h"
using namespace std;
int main() {
    try {
        MyString a("OI");
        MyString b("ola");

        cout << b.getMyString();
        cout << b.at(0);
        b.at(0) = 'X';
        cout << b.getMyString();
        b.concat(a);
        cout << b.getMyString();

        MyString copia(a);
        b=a;
    }catch(const char *p){
        cerr << "Excessao gerada" << p;
    }
    return 0;
}
