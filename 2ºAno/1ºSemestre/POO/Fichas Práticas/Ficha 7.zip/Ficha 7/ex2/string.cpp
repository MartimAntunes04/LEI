//
// Created by ASUS on 22/11/2023.
//
#include "iostream"
#include "sstream"
#include "string.h"
using namespace std;

MyString::MyString(){
    p= nullptr;
    tam=0;
    std::cout << "Contrutor por omissao" << endl;
}

MyString::MyString(const char *s) {
    tam= strlen(s);
    p=new char [tam+1];
    strcpy(p,s);
    std::cout << "Contrutor " << p << endl;
}

const char * MyString::getMyString() const
{
    if(p== nullptr)
        return "NULLPTR";
    return p;
}

char & MyString::at(int indice) {
    if(indice>=0 && indice< tam)
        return p[indice];
    throw "Indice invalido";
}

void MyString::concat(const MyString &outro) {

    //Reservar espaco novo tam+outro.tam+1
    char *aux=new char[tam+outro.tam+1];

    //Copiar o texto antigo para espaco novo
    strcpy(aux,this->p);



    //Acrescentar texto do outro e atualizar tam
    strcat(aux,outro.p);
    tam+=outro.tam;

    //Apagar espaco antigo
    delete[]this->p;
    p=aux;
}

MyString &MyString::operator=(const MyString &outro) {
    if(this != &outro) {
        //Apagar espco antigo
        delete[]p;

        //Reservar espaco novo
        p = new char[outro.tam + 1];

        //Copiar texto e tam do outro
        strcpy(p, outro.p);
        tam = outro.tam;


    }
    return *this;
}

MyString::MyString(const MyString &outro) {
    p= nullptr;
    *this=outro;
}