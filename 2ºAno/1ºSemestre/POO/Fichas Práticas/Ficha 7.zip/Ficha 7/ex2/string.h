//
// Created by ASUS on 22/11/2023.
//

#ifndef EX2_STRING_H
#define EX2_STRING_H
#include <iostream>
#include <cstring>
#include <sstream>
class MyString{
    char *p;
    int tam;
public:
    MyString();
    MyString(const char *p);
    MyString(const MyString & outro);              //copia
    MyString & operator=(const MyString & outro);  //operador atribuicao
    ~MyString(){
        std::cout << "Destrutor" << p;
        delete[]p;
        p= nullptr;
    }

    const char * getMyString()const;
    char & at (int indice);
    void concat(const MyString &outro);



};
#endif //EX2_STRING_H
