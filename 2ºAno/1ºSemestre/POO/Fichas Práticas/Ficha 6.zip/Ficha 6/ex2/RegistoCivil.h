//
// Created by ASUS on 08/11/2023.
//

#ifndef EX2_REGISTOCIVIL_H
#define EX2_REGISTOCIVIL_H
#include <iostream>
#include <sstream>
#include "pessoa.h"
#include <vector>
#include "pessoa.h"
using namespace std;
class RegistoCivil{

    string pais;
    int total;
    vector<Pessoa>pessoas;
public:
    RegistoCivil(const string &n);
    ~RegistoCivil();

    string getString()const;
    string getPais()const;
    bool regista(string &name,long num_ident,long num_cont);
    int verifica(int num_ident)const;
    void registaDoFicheiro(const std::string & ficheiro);
    string getPessoaNome(int num_ident)const;
    bool apaga(int num_ident);
    bool atualizanome(int num_ident,string &n);
    int getTotal()const;
    Pessoa *getPessoa(int num_ident);

};

#endif //EX2_REGISTOCIVIL_H
