//
// Created by ASUS on 08/11/2023.
//

#ifndef EX2_PESSOA_H
#define EX2_PESSOA_H
#include <istream>
using namespace std;
class Pessoa{
    string nome;
    int BI,NIF;
public:
    Pessoa(const string &name="vazio",int num_ident=0,int num_cont=0);
    ~Pessoa();
    string getString()const;
    string atualizanome(const string &novonome);
    int getId()const;
    string getNome() const;
    void setNome(string newnome);
};
#endif //EX2_PESSOA_H
