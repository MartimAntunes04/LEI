//
// Created by ASUS on 08/11/2023.
//
#include "pessoa.h"
#include <istream>
#include <sstream>
#include <string>
#include <iostream>
using namespace std;

Pessoa::Pessoa(const string &name, int num_ident, int num_cont) {
    nome=name;
    BI=num_ident;
    NIF=num_cont;
}

Pessoa::~Pessoa() {
   // cout << "Destruindo pessoa" << nome<< endl;
}

string Pessoa::getString() const {
    ostringstream os;
    os << nome << "com BI: " << BI << " e NIF: " <<NIF;
    return os.str();
}

string Pessoa::atualizanome(const string &novonome)  {
    nome=novonome;
    return nome;
}

int Pessoa::getId() const {
    return BI;
}

string Pessoa::getNome() const {
    return nome;
}

void Pessoa::setNome(string newnome) {
    nome=newnome;
}