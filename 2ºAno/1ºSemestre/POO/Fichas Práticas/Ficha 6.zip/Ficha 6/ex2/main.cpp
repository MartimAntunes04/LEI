#include <iostream>
#include <vector>
#include <map>
#include <set>
#include "sstream"
#include "pessoa.h"
#include "RegistoCivil.h"

using namespace std;
int main() {
    vector<RegistoCivil>registos{RegistoCivil("Portugal")};
    registos.emplace_back("Espanha");




    auto it=registos.begin();
    while(it!=registos.end()) {
        cout << it->getString() << " ";
        it++;
    }


    return 0;
}
