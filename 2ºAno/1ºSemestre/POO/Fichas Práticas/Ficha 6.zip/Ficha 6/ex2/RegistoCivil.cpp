//
// Created by ASUS on 08/11/2023.
//

#include <iostream>
#include <sstream>
#include "RegistoCivil.h"
#include "pessoa.h"
#include <fstream>
using namespace std;
RegistoCivil::RegistoCivil(const string &n):pais(n),total(0) {

    cout << "Contruindo Registo Civil" << pais << endl;
}

RegistoCivil::~RegistoCivil() {
    //cout << "Destrindo Registo Civil" << pais << endl;
}


string RegistoCivil::getString() const {
    ostringstream os;
    os << "Registo Civil " << pais << " com os " << total << " registos:\n";
    auto it=pessoas.begin();
    while(it!=pessoas.end())
        if(it->getId()!=0)
            os<<getString();
    return os.str();
}

string RegistoCivil::getPais() const {
    return pais;
}

int RegistoCivil::verifica(int num_ident) const {  //Se existir retorna o índice , se não é -1
    int indice=-1;
    for(int i=0;i<pessoas.size();i++){
        if(pessoas[i].getId()==num_ident){
            indice = i;
            break;
        }
    }
    return indice;
}

bool RegistoCivil::regista(string &n,long num_ident,long num_cont){
    if(verifica(num_ident) == -1 && total <pessoas.size()){
        for(int i=0; i < pessoas.size(); i++)//encontrar uma posição vaga
            if(pessoas[i].getId()==0){
                pessoas[i]=Pessoa(n, num_ident, num_cont);
                total++;
                return true;
            }
        //Se não encontrou uma vaga é porque está cheio
    }
    return false;
}

void RegistoCivil::registaDoFicheiro(const std::string &ficheiro) {
    ifstream fich(ficheiro);
    if(fich) {//ficheiro encontrado e aberto
        string linha,parte;
        int nif,id;
        while(getline(fich,linha)){
            istringstream is(linha);
            if(is>>parte && is >> id && is >> nif){
                regista(parte,id,nif);

            }
        }
    }
}

string RegistoCivil::getPessoaNome(int num_ident) const {
    int indice;
    for(int i=0;i<pessoas.size();i++){
        if((indice= verifica(num_ident))!=-1){
            return pessoas[indice].getNome();
        }
    }
    return "Nao encontrado";
}

bool RegistoCivil::apaga(int num_ident) {
    int indice;
    if((verifica(num_ident))==-1){
        return false;
    }
    pessoas[indice]=Pessoa();
    total--;
    return true;
}

bool RegistoCivil::atualizanome(int num_ident, string &n) {
    int indice;
    if((verifica(num_ident))!=-1){
        pessoas[indice].setNome(n);
        return true;
    }
    return false;
}

int RegistoCivil::getTotal() const {
    return total;
}

Pessoa *RegistoCivil::getPessoa(int num_ident) {
    //Se não encontrar retorna nullptr
    int indice= verifica(num_ident);
    if(indice!=-1)
        return &(pessoas[indice]);
    return nullptr;
}