//
// Created by ASUS on 25/10/2023.
//
#include "fracao.h"
#include <iostream>

int Fracao::getNum() const{
    return num;
};

int Fracao::getDen() const {
    return den;
}

void Fracao::setNum(int n) {
    num=n;
}

void Fracao::setDen(int n) {
    if(n>0){
        den=n;
    }

}



Fracao & /*Fracao::*/operator*=( Fracao &f1, const Fracao &f2) {
    f1.setNum(f1.getNum() * f2.getNum());
    f1.setDen(f1.getDen() * f2.getDen());
    return f1;
    // *this = *this * outra;
    // return *this;
}

Fracao &Fracao::operator++() {
    num += den;
    return *this;
}

Fracao Fracao::operator++(int) {
    Fracao nova(*this); //Cópia do objeto atual antes da modificação
    num += den;
    return nova;
}

Fracao::operator string() const {
    return this->getAsString();
}

ostream &operator<<(ostream &os, const Fracao &fracao) {
    os << fracao.getAsString();
    return os;
}

bool operator==(const Fracao &lhs, const Fracao &rhs) {
    return lhs.getNum() == rhs.getNum() &&
           lhs.getDen() == rhs.getDen();
}

bool operator!=(const Fracao &lhs, const Fracao &rhs) {
    return !(rhs == lhs);
}

Fracao operator*(const Fracao &lhs, const Fracao &rhs){
    Fracao nova(lhs.getNum()*rhs.getNum(), lhs.getDen()*rhs.getDen());
    return nova;
}

Fracao operator/(const Fracao &lhs, const Fracao &rhs){
    Fracao nova(lhs.getNum()*rhs.getDen(), lhs.getDen()*rhs.getNum());
    return nova;
}

std::istream &operator>>(std::istream &is, Fracao &fracao){
    int n, d;
    cout << "Numerador:";
    is >> n;
    fracao.setNum(n);
    cout << "Denominador:";
    is >> d;
    fracao.setDen(d);
    return is;
}

//Novos dados - funções, e alteradas
int Fracao::contador=0;

std::string Fracao::getAsString() const {
    ostringstream buffer;
    buffer << num << '/' << den << "(id:" << id << " contador:" << contador << ")";
    return buffer.str();
}

Fracao::Fracao(int num, int den) : num(num), den(den) {id=++contador;}

Fracao::Fracao(const Fracao &o){
    *this = o;
    this->id=++contador;
}
Fracao & Fracao::operator=(const Fracao &o){
    if(this != &o){
        this->num = o.num;
        this->den = o.den;
    }
    return *this;
}
int & Fracao::operator[](int indice){
    if(indice==0) return num;
    if(indice==1) return den;
    throw "Index does not exist!";
}
Fracao & Fracao::operator()(int valor){
    *this *= valor;
    return *this;
}

int Fracao::getID()const{
    return id;
}


//n
void func(string n) {
    cout << n;  // aparece o texto da fração
}

bool operator<(const Fracao &f1, const Fracao & f2){
    return (float)f1.getNum()/f1.getDen() < (float)f2.getNum()/f2.getDen();
}