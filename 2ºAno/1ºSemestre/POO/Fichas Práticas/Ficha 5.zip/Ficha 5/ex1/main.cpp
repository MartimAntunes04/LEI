#include <iostream>
#include "fracao.h"
using namespace std;
int main() {
    //a
    Fracao a(1,2),b(3);
    const Fracao c(3,4);

    cout<< "a)\nNumeradores: "<< a.getNum() << " " << b.getNum()<< " " << c.getNum() << endl;
    cout << "Denominadores:" << a.getDen() << " " << b.getDen()<< " " << c.getDen() << endl;
    //apenas o objeto constante não pode ser modificado
    b.setDen(1);

    //b
    a= b * c;
    cout << "b)\na=" << a << "\nb=" << b << "\nc=" << c << endl;

    //c
    //cout << "c)\n Resultado de a * b * c:" << a * b * c << endl;

    //d
    a= b * 4;//o construtor é chamado implicitamente
    cout << "d)\n Resultado de b * 4 ----> a=" << a << endl;

    //f
    a= 4 * b;
    cout << "f)\n Resultadp de 4 * b ----> a=" << a<< endl;

    //g
    cout << "\ng)\n" << a << endl;

    //h
    cout << "h)\na=" << a << "\nb=" << b << "\nc=" << c << endl;

    //j
    a *= b;
    cout << "j)\n Resultado de a*=b ----> a=" << a << endl;

    //k
    a *= b *=c;
    cout << "k)\nResultado de a*=b*=c -----> a=" << a << "\nb=" << b << "\nc="<< c << endl;

    //l -> letras sofreram um shift de 3 a->d, b->e, c->f
    Fracao d(1,2),e(2,3),f(3,4);

    (d *= e) *=f;
    cout << "l)\nResultado de (d*=e)*=f---->) d=" << d << endl;

    //m
    cout << "m)\nResultado de d++ ----->" << d++ << endl;//Aparece ainda o valor antigo 6/24, mas depois fica incremetado para 30/24
    cout << "d=" << d << endl;
    cout << "O resultado de ++e ---->" << ++e << endl;
    // c++ e ++c nao compila

    //n -> letra sofreu um shift de 1 f->g
    const Fracao g(7,3);
    func(g);// é passado automaticamente o valor char da fração

    //o
    if(a==b)
        cout << "\no)\nFracoes a e b sao iguais\n";

    if(a!=b)
        cout << "\no)\nFracoes a e b sao diferentes\n";

    //q
    Fracao x(2,1),y(1,3),z(1);
    cout << "q)\nz= " << z << endl;
    //z=x*y;
    //cout << x << " * " << y << " = " << z << endl;
    z=x/y;
    cout << x << " / " << y << " = " << z << endl;

    Fracao  h(2,-4),j(2);
    cout << " h= " << h << " j= " << j << endl;
    h *= j;
    cout << "h *= j " << endl;
    cout << "h= " << h << "j= " << j << endl;
    return 0;
}
