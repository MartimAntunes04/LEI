//
// Created by ASUS on 25/10/2023.
//

#ifndef EX1_FRACAO_H
#define EX1_FRACAO_H
#include <sstream>
#include <fstream>
#include <iostream>
using namespace std;
class Fracao{
    int num,den;
    int id;
    static int contador;
public:

    /*explicit*/ Fracao(int num, int den=1);
    int getNum()const;
    int getDen()const;
    void setNum(int n);
    void setDen(int n);
    string getAsString()const;

    // Fracao & operator*=(const Fracao & outra);
    Fracao operator*(Fracao &outra);
    Fracao & operator++(); //Pré-fixo
    Fracao operator++(int); //Pós-fixo
    operator string() const; //Operador conversão

    //Novas funções
    Fracao(const Fracao &o);
    Fracao & operator=(const Fracao &o);
    int & operator[](int indice);
    Fracao & operator()(int valor);
    int getID()const;
};

bool operator==(const Fracao &lhs, const Fracao &rhs);
bool operator!=(const Fracao &lhs, const Fracao &rhs);
Fracao operator*(const Fracao &lhs, const Fracao &rhs);
Fracao operator/(const Fracao &lhs, const Fracao &rhs);
ostream &operator<<(ostream &os, const Fracao &fracao);
istream &operator>>(istream &os, Fracao &fracao);
Fracao & operator*=(Fracao & f, const Fracao & outra);
void func(string n);
//Devido ao set
bool operator<(const Fracao &f1, const Fracao & f2);
#endif //EX1_FRACAO_H
