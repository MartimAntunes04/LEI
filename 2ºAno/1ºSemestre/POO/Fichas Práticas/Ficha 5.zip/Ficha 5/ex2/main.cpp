#include <iostream>
#include "vetor.h"
using namespace std;
int main() {

    Vetor v1(2.0, 1.0), v2(1.0, 3.0), v3(2.2,0), z(0,0);
    z= v1 + v2;

    cout << v1.getString() << "+" << v2.getString()  << "=" << z.getString() << endl; // obs: "(x,y)"


    return 0;
}
