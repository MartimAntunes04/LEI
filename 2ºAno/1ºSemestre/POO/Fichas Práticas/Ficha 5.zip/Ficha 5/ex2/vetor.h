//
// Created by ASUS on 25/10/2023.
//
#include "string"
#ifndef EX2_VETOR_H
#define EX2_VETOR_H


class Vetor{
    double x,y;
public:
    Vetor(double coordenadax,double coordenaday);
    std::string getString()const;
    int getX()const;
    int getY ()const;
    Vetor operator+(const Vetor &outro);
    Vetor operator-(const Vetor &outro)
};



#endif //EX2_VETOR_H
