//
// Created by ASUS on 25/10/2023.
//
#include "vetor.h"
#include <iostream>
#include <ostream>
#include <string>
using namespace std;
Vetor::Vetor(double coordenadax, double coordenaday) {
    x=coordenadax;
    y=coordenaday;
}

ostringstream os Vetor:: getString()const{
    os << "("<< x << ","<< y<<")";
}

int Vetor::getX()const{
    return x;
}

int Vetor::getY()const{
    return y;
}

Vetor Vetor::operator+(const Vetor &outro) {
    Vetor novo  (x+outro.x , y +outro.y );
    return novo;
}

Vetor Vetor::operator-(const Vetor &outro) {
    Vetor novo (x-outro.x, y-outro.y);
    return novo;
}