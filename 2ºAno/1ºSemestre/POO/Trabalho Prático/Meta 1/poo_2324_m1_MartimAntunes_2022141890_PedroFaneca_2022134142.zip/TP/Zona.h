//
// Created by ASUS on 01/11/2023.
//

#ifndef POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_ZONA_H
#define POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_ZONA_H
#include "Sensor.h"
#include "Aparelho.h"
#include "Processador.h"
#include "Propriedade.h"
#include <map>
class Zona{
    int x,y;
    int id_z;
    static int contador_z;
    vector <Sensor>sensores;
    vector <Aparelho>aparelhos;
    vector <Processador>processadores;
    vector <Propriedade>propriedades;

public:
    Zona(int x,int y);
    int getId() const;
    string getString()const;

    void AdicionarPropriedade(const string &nome,double valor,double val_min,double val_max,string unidade);
    void listarPropriedades()const;

};




#endif //POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_ZONA_H
