//
// Created by ASUS on 01/11/2023.
//
#include "utils.h"
#include "Propriedade.h"

Propriedade::Propriedade(string nome, double val, double val_min, double val_max,string unidade_) {
    tipo=nome;
    unidade=unidade_;
    valor=val;
    valor_min=val_min;
    valor_max=val_max;


}

string Propriedade::gettipo() const {
    return tipo;
}

string Propriedade::getunidade()const{
    return unidade;
}

double Propriedade::getvalor() const {
    return valor;
}

void Propriedade::setVvalor(double novovalor) {
    if (novovalor >= valor_min && novovalor <= valor_max) {
        valor = novovalor;
    }
    else{
        printf("O valor que colocou nao esta entre os valores minimos e maximos");
    }
}

string Propriedade::getString() const {
    ostringstream os;
    os << "(" << tipo << "," << valor <<  unidade <<")";
    return os.str();
}