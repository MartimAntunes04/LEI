//
// Created by ASUS on 22/11/2023.
//

#ifndef POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_COMANDOS_H
#define POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_COMANDOS_H

#include "utils.h"
#include "Terminal.h"

class Comando{

    std::vector <std::string>args; //vai guardar os tokens de um comando;
    term::Window &w;


public:

    Comando(std::string command,term::Window &w);
    ~Comando();
    void executa();
    void cmd_prox(Comando *cmd);
    void cmd_avanca(Comando *cmd);
    void cmd_hnova(Comando *cmd);
    void cmd_hrem(Comando *cmd);
    void cmd_znova(Comando *cmd);
    void cmd_zrem(Comando *cmd);
    void cmd_zlista(Comando *cmd);
    void cmd_zcomp(Comando *cmd);
    void cmd_zprops(Comando *cmd);
    void cmd_pmod(Comando *cmd);
    void cmd_cnovo(Comando *cmd);
    void cmd_crem(Comando *cmd);
    void cmd_rnova(Comando *cmd);
    void cmd_pmuda(Comando *cmd);
    void cmd_rlista(Comando *cmd);
    void cmd_rrem(Comando *cmd);
    void cmd_asoc(Comando *cmd);
    void cmd_ades(Comando *cmd);
    void cmd_acom(Comando *cmd);
    void cmd_psalva(Comando *cmd);
    void cmd_prem(Comando *cmd);
    void cmd_plista (Comando *cmd);
    void cmd_exec(Comando *cmd);
    bool leFicheiro(const std::string &ficheiro);
};


#endif //POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_COMANDOS_H
