//
// Created by ASUS on 15/11/2023.
//

#include "utils.h"
#include "Processador.h"
using namespace std;

Processador::Processador() {id=++contador;}

int Processador::contador=0;

int Processador::getId() const {
    return id;
}

string Processador::getString() const {
    ostringstream os;
    os << "Processador " << tipo << id << "\nRegras associadas:\n";
    for(const auto &regra:regras){
        os << regra.getString() << '\n';
    }
    return os.str();
}

