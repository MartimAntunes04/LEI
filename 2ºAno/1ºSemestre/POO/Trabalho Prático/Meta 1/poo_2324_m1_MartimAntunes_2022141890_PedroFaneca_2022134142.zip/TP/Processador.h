//
// Created by ASUS on 15/11/2023.
//

#ifndef POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_PROCESSADOR_H
#define POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_PROCESSADOR_H
#include "utils.h"
#include <vector>
#include <map>
#include "Regra.h"
#include "Aparelho.h"
class Processador{
    string tipo="p";
    int id;
    static int contador;
    vector <Regra> regras;  //processador e dono sas regras
    vector<Aparelho*>aparelho; //processador conhece aparelho
    vector <Sensor*>sensores;

public:
    Processador();
    int getId()const;
    string getString()const;
};


#endif //POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_PROCESSADOR_H
