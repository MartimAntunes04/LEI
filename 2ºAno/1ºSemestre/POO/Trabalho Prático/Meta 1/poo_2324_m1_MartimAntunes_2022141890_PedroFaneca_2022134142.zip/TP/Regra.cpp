//
// Created by ASUS on 15/11/2023.
//

#include "Regra.h"

Regra::Regra(string descricao_,double valorComparacao1_,double valorComparacao2_) : descricao(descricao_),valorComparacao1(valorComparacao1_),valorComparacao2(valorComparacao2_){id=++contador;}

int Regra::contador=0;

int Regra::getId() const {
    return id;
}

string Regra:: getDescricao()const{
    return descricao;
}

double Regra::getvalor1() const {
    return valorComparacao1;
}

double Regra::getvalor2() const {
    return valorComparacao2;
}

string Regra:: getString()const{
    ostringstream os;
    os << "Regra " << tipo << id << ":" << descricao;
    if (descricao == "entre" || descricao == "fora") {
        os << " " << valorComparacao1 << " e " << valorComparacao2;
    } else {
        os << " " << valorComparacao1;
    }
    return os.str();
}

