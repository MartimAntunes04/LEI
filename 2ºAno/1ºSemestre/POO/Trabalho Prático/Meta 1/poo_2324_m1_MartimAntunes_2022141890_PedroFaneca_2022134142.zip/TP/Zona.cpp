//
// Created by ASUS on 01/11/2023.
//

#include "utils.h"
#include "Zona.h"

Zona::Zona(int x,int y): x(x),y(y) {id_z=++contador_z;}

int Zona::contador_z=0;


int Zona::getId() const {
    return id_z;
}

string Zona::getString() const{
    ostringstream os;
    os << "Zona " << id_z << "em x= " << x << "e y= " << y;
    return os.str();
}



void Zona::AdicionarPropriedade(const string &nome, double valor, double val_min, double val_max, string unidade) {
    propriedades.push_back(Propriedade(nome,valor,val_min,val_max,unidade));
}

void Zona::listarPropriedades() const {
    cout << "Propriedades na zona " << id_z << ":\n";
    for (const auto &propriedade: propriedades) {
        cout << "(" << propriedade.gettipo() << "," << propriedade.getvalor() << propriedade.getunidade() << " ) \n";
    }
}