//
// Created by ASUS on 08/11/2023.
//
#include "utils.h"
#include "Sensor.h"


Sensor::Sensor(string zona,string chave) : zona(zona),propriedade(chave) {id=++contador;}

int Sensor::contador=0;

int Sensor::getId() const {
    return id;
}

string Sensor::getString()const{
    ostringstream os;
    os << "Sensor " << tipo << id << " da zona " << zona <<endl;
    return os.str();
}


