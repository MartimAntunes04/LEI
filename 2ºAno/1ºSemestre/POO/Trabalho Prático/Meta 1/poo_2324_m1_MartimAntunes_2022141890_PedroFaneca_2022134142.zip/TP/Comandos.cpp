//
// Created by ASUS on 22/11/2023.
//
#include "utils.h"
#include "Comandos.h"
#include "vector"
#include "Zona.h"
#include "Propriedade.h"
using namespace std;


Comando::Comando(string command, term::Window &w) : w(w) {
    istringstream iss(command);
    string token;
    while (iss >> token) {
        args.push_back(token);
    }
}

Comando::~Comando() {
    cout << "Destruir";
}
void Comando:: executa() {
    if (args.empty()) {
        w << "[INVALIDO] Comando ausente" << '\n';
        return;
    }

    string comando = args[0];

    if (comando == "prox") {
        cmd_prox(this);
    }

    else if(comando == "avanca"){
        cmd_avanca(this);
    }

    else if(comando == "hnova"){
        cmd_hnova(this);
    }

    else if(comando == "hrem"){
        cmd_hrem(this);
    }

    else if(comando == "znova"){
        cmd_znova(this);
    }

    else if(comando == "zrem"){
        cmd_zrem(this);
    }

    else if(comando == "zlista"){
        cmd_zlista(this);
    }

    else if(comando == "zcomp"){
        cmd_zcomp(this);
    }

    else if(comando == "zprops"){
        cmd_zprops(this);
    }

    else if(comando == "pmod"){
        cmd_pmod(this);
    }


    else if(comando == "cnovo"){
        cmd_cnovo(this);
    }

    else if(comando == "crem"){
        cmd_crem(this);
    }

    else if(comando == "rnova"){
        cmd_rnova(this);
    }

    else if(comando == "pmuda"){
        cmd_pmuda(this);
    }

    else if(comando == "rlista"){
        cmd_rlista(this);
    }

    else if(comando == "rrem"){
        cmd_rrem(this);
    }

    else if(comando == "asoc"){
        cmd_asoc(this);
    }

    else if(comando == "ades"){
        cmd_ades(this);
    }

    else if(comando == "acom"){
        cmd_acom(this);
    }

    else if(comando == "psalva"){
        cmd_psalva(this);
    }

    else if(comando == "prem"){
        cmd_prem(this);
    }

    else if(comando == "plista"){
        cmd_plista(this);
    }

    else if(comando == "exec"){
        cmd_exec(this);
    }

    else {
        w << "Comando desconhecido: " << comando << '\n';
    }
}

void Comando::cmd_prox(Comando *cmd) {
    if(cmd->args.size() != 1){
        cmd->w << "Comando invalido!" << '\n';
        return;
    }
    cmd->w <<  "Comando valido!" << "\n";

}


void Comando::cmd_avanca(Comando *cmd) {
    if(cmd->args.size() != 2){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    try {
        int n = stoi(segundoArg);
        cmd->w << "Comando valido!\n";
        cmd->w << "Avanca " << n << " instantes" << '\n';

        //  avançar uma certa quantidade)


    } catch (invalid_argument&) {
        cmd->w << "Comando invalido! O segundo argumento tem de ser um numero inteiro\n";
    } 
}

void Comando::cmd_hnova(Comando *cmd) {
    if(cmd->args.size() !=3){
        cmd->w << "Comando invalido!\n";
        return;
    }
    string segundoArg = cmd->args[1];
    string terceiroArg = cmd->args[2];
    try{
        int num_linhas= stoi(segundoArg);
        int num_colunas = stoi(terceiroArg);
        cmd->w << "Comando valido!\n";
        cmd->w << "Criar habitacao com tamanho " << num_linhas << " x " <<num_colunas << "\n";
        //CRIAR HABITACAO

    }catch(invalid_argument&){
        cmd->w << "Comando invalido! O numero de linhas e colunas tem de ser numeros inteiros\n";
    }
}


void Comando::cmd_hrem(Comando *cmd) {
    if(cmd->args.size() !=1){
        cmd->w << "Comando invalido!\n";
        return;
    }
    cmd->w <<  "Comando valido!" << "\n";
}


void Comando::cmd_znova(Comando *cmd) {
    if(cmd->args.size() !=3){
        cmd->w << "Comando invalido!\n";
        return;
    }
    string segundoArg = cmd->args[1];
    string terceiroArg = cmd->args[2];
    try{
        int linha= stoi(segundoArg);
        int coluna = stoi(terceiroArg);
        cmd->w << "Comando valido!\n";
        cmd->w << "Criar zona na linha " << linha << " e coluna " << coluna << '\n';
        //CRIAR HABITACAP

    }catch(invalid_argument&){
        cmd->w << "Comando invalido! O numero da linha e coluna tem de ser numeros inteiros\n";
    }
}

void Comando::cmd_zrem(Comando *cmd) {
    if(cmd->args.size() != 2){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    try {
        int id = stoi(segundoArg);
        cmd->w << "Comando valido!\n";
        cmd->w << "Apagar zona com id "<< id << '\n';
        // APAGAR A ZONA COM ESTE ID

    } catch (invalid_argument&) {
        cmd->w << "Comando invalido! O id da zona tem de ser um numero inteiro\n";
    }
}


void Comando::cmd_zlista(Comando *cmd) {
    if(cmd->args.size() != 1){
        cmd->w << "Comando invalido!" << '\n';
        return;
    }
    cmd->w <<  "Comando valido!" << "\n";
}

void Comando::cmd_zcomp(Comando *cmd) {
    if(cmd->args.size() != 2){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    try {
        int id = stoi(segundoArg);
        cmd->w << "Comando valido!\n";

        // Lista os componentes da zona com este id


    } catch (invalid_argument&) {
        cmd->w << "Comando invalido! O id da zona tem de ser um numero inteiro\n";
    }
}


void Comando::cmd_zprops(Comando *cmd) {
    if(cmd->args.size() != 2){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    try {
        int id = stoi(segundoArg);
        cmd->w << "Comando valido!\n";

        // Lista as propriedades da zona com este id

    } catch (invalid_argument&) {
        cmd->w << "Comando invalido! O id da zona tem de ser um numero inteiro\n";
    }
}


void Comando::cmd_pmod(Comando *cmd) {
    if(cmd->args.size() != 4){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    string terceiroArg = cmd ->args[2];
    string quartoArg = cmd->args[3];

    try{
        int id = stoi(segundoArg);
        // Verificar se o terceiro argumento (nome da propriedade) contém números
        if (terceiroArg.find_first_of("0123456789") != std::string::npos) {
            throw invalid_argument("Nome da propriedade contém números.");
        }
        double valor_prop = stod(quartoArg);
        cmd->w << "Comando valido!\n";
        cmd->w << "Zona " << id << " ,propriedade " << terceiroArg << " muda para "<< valor_prop << '\n' ;
    }catch (invalid_argument&){
        cmd->w << "Comando invalido! Digite pmov <id_zona> <nome_prop> <valor_novo>\n";
    }
}

void Comando::cmd_cnovo(Comando *cmd) {
    if(cmd->args.size() != 4){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg= cmd->args[1];
    string terceiroArg = cmd->args[2];
    string quartoArg = cmd->args[3];

    try{
        int id = stoi(segundoArg);

        // Verificando se o terceiro argumento (componente) contém exatamente um caractere
        if (terceiroArg.size() != 1 || !std::isalpha(terceiroArg[0])) {
            throw invalid_argument("O componente deve conter exatamente um caractere.");
        }
        if(terceiroArg == "s"){
            cmd->w << "Comando valido!\n";
            cmd->w << "Na zona " << id << " adicionar sensor de " << quartoArg << '\n';
        }
        else if(terceiroArg == "p"){
            cmd->w << "Comando valido!\n";
            cmd->w << "Na zona " << id << " e realizado o comando " << quartoArg << '\n';
        }
        else if(terceiroArg == "a"){
            cmd->w << "Comando valido!\n";
            cmd->w << "Na zona " << id << " adicionar o aparelho " << quartoArg << '\n';
        }
        else{
            cmd->w << "So pode adicionar s(sensor), p(processador),a(aparelho)\n";
        }

    }catch (invalid_argument&){
        cmd->w << "Comando invalido!Digite cnovo <id_zona> <s|p|a> <tipo|comando>\n";
    }
}


void Comando::cmd_crem(Comando *cmd) {
    if(cmd->args.size() != 4){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg= cmd->args[1];
    string terceiroArg = cmd->args[2];
    string quartoArg = cmd->args[3];

    try{
        int id_zona = stoi(segundoArg);
        char tipo_componente = quartoArg[0];// A primeira letra indica o tipo de componente
        int valorInteiro = stoi(quartoArg.substr(1)); // O restante é o valor inteiro

        // Verificando se o terceiro argumento (componente) contém exatamente um caractere
        if (terceiroArg.size() != 1 || !std::isalpha(terceiroArg[0])) {
            throw invalid_argument("O componente deve conter exatamente um caractere.");
        }
        if(terceiroArg == "s"){
            cmd->w << "Comando valido!\n";
            cmd->w << "Na zona " << id_zona << " remover sensor com id " << tipo_componente <<valorInteiro <<'\n';
        }
        else if(terceiroArg == "p"){
            cmd->w << "Comando valido!\n";
            cmd->w << "Na zona " << id_zona << " remover processador com id " << tipo_componente << valorInteiro << '\n';
        }
        else if(terceiroArg == "a"){
            cmd->w << "Comando valido!\n";
            cmd->w << "Na zona " << id_zona << " remover aparelho com id " << tipo_componente << valorInteiro << '\n';
        }
        else{
            cmd->w << "So pode remover s(sensor), p(processador),a(aparelho)\n";
        }



    }catch (invalid_argument&){
        cmd->w << "Comando invalido!Digite crem <id_zona> <s|p|a> <id_componente>\n";
    }
}


void Comando::cmd_rnova(Comando *cmd) {
    if(cmd->args.size() <= 5){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg= cmd->args[1];
    string terceiroArg = cmd->args[2];
    string quartoArg = cmd->args[3];
    string quintoArg = cmd->args[4];

    try{
        int id_zona = stoi(segundoArg);

        char tipoComponente = terceiroArg[0];
        if(tipoComponente != 'p'){
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 'p' seguido do valor inteiro para o processador de regras.\n";
            return;
        }
        int valorInteiro = stoi(terceiroArg.substr(1));

        string regra = quartoArg;

        char tipoComponente_ = quintoArg[0];
        if(tipoComponente_ != 's'){
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 's' seguido do valor inteiro para o sensor respetivo.\n";
            return;
        }
        int valorInteiro_ = stoi(quintoArg.substr(1));



        int numParametrosAdicionais = 0;

        if (regra == "maior_que" || regra == "menor_que" || regra == "igual_a") {

            numParametrosAdicionais = 1;
            for (int i = 0; i < numParametrosAdicionais; i++) {
                cmd->w << "Na zona " << id_zona << " no processador " << tipoComponente << valorInteiro << ", regra: " << regra << " " << args[5] << " associada ao sensor " << tipoComponente_ << valorInteiro_ << '\n';
            }
        } else if (regra == "entre" || regra == "fora") {

            numParametrosAdicionais = 2;
            cmd->w << "Na zona " << id_zona << " no processador " << tipoComponente << valorInteiro << ", regra: " << regra << " " << args[5] << " e " << args[6] << " associada ao sensor " << tipoComponente_ << valorInteiro_ << '\n';
        }

        cmd->w << "Comando valido!\n";


    }catch (invalid_argument&){
        cmd->w << "Comando invalido!Digite rnova <id_zona> <id_processador> <regra> <id_sensor> [param1] [param2] [...]\n";
    }

}

void Comando::cmd_pmuda(Comando *cmd) {
    if(cmd->args.size() != 4){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    string terceiroArg = cmd->args[2];
    string quartoArg = cmd->args[3];

    try{
        int id_zona=stoi(segundoArg);
        char tipoComponente = terceiroArg[0];
        int valorInteiro = stoi(terceiroArg.substr(1));
        string novo_comando=quartoArg;

        if(tipoComponente != 'p'){
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 'p' seguido do valor inteiro para o processador de regras.\n";
            return;
        }


        cmd->w << "Comando valido!\n";
        cmd->w << "Na zona " << id_zona << " ,no processador " << tipoComponente << valorInteiro << " ,o novo comando e " << novo_comando << '\n';
    }catch(invalid_argument&){
        cmd->w << "Comando invalido!Digite pmuda <id_zona> <id_proc.regras> <novo comando>\n";
    }
}


void Comando::cmd_rlista(Comando *cmd) {
    if(cmd->args.size() !=3){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    string terceiroArg = cmd ->args[2];

    try{
        int id_zona = stoi(segundoArg);
        char tipoComponente = terceiroArg[0];
        int valorInteiro = stoi(terceiroArg.substr(1));

        if(tipoComponente != 'p'){
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 'p' seguido do valor inteiro para o processador de regras.\n";
            return;
        }

        cmd->w << "Comando valido!\n";

        //LISTA AS REGRAS DO PROCESSADOR

    }catch(invalid_argument&){
        cmd->w << "Comando invalido!Digite rlista <id_zona> <id_proc.regras>\n";
    }

}

void Comando::cmd_rrem(Comando *cmd) {
    if(cmd->args.size() != 4){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    string terceiroArg = cmd->args[2];
    string quartoArg = cmd->args[3];

    try{
        int id_zona = stoi(segundoArg);
        char tipoComponente = terceiroArg[0];
        int valorInteiro = stoi(terceiroArg.substr(1));
        char regra = quartoArg[0];
        int valorInteiro_=stoi(quartoArg.substr(1));
        if (tipoComponente != 'p') {
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 'p' seguido do valor inteiro para o processador de regras.\n";
            return;
        }

        if(regra != 'r'){
            cmd->w << "Regra invalida: " << tipoComponente << ". Digite 'r' seguido do valor inteiro da respetiva regra.\n";
        }
        cmd->w << "Comando valido!\n";
        cmd->w<< "Na zona " << id_zona << " no processador de regras " << tipoComponente << valorInteiro << " remover a regra " << regra << valorInteiro_ << '\n';
    }catch(invalid_argument&){
        cmd->w << "Comando invalido! Digite rrem <id_zona> <id_proc.regras> <id_regra>\n";
    }
}


void Comando::cmd_asoc(Comando *cmd) {
    if(cmd->args.size() != 4){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    string terceiroArg = cmd->args[2];
    string quartoArg = cmd->args[3];

    try{
        int id_zona = stoi(segundoArg);
        char tipoComponente = terceiroArg[0];
        int valorInteiro = stoi(terceiroArg.substr(1));
        char tipoComponente_ = quartoArg[0];
        int valorInteiro_=stoi(quartoArg.substr(1));

        if (tipoComponente != 'p') {
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 'p' seguido do valor inteiro para o processador de regras.\n";
            return;
        }

        if(tipoComponente_ != 'a'){
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 'a' seguido do valor inteiro para o aparelho respetivo.\n";
            return;
        }
        cmd->w << "Comando valido!\n";
        cmd->w << "Para a zona " << id_zona << " associado a saida do processador " << tipoComponente << valorInteiro << " com o aparelho " << tipoComponente_ << valorInteiro_ << '\n';
    }catch (invalid_argument&){
        cmd->w << "Comando invalido!Digite asoc <id_zona> <id_proc.regras> <id_aparelho>\n";
    }
}

void Comando::cmd_ades(Comando *cmd) {
    if(cmd->args.size() != 4){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    string terceiroArg = cmd->args[2];
    string quartoArg = cmd->args[3];

    try{
        int id_zona = stoi(segundoArg);
        char tipoComponente = terceiroArg[0];
        int valorInteiro = stoi(terceiroArg.substr(1));
        char tipoComponente_ = quartoArg[0];
        int valorInteiro_=stoi(quartoArg.substr(1));

        if (tipoComponente != 'p') {
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 'p' seguido do valor inteiro para o processador de regras.\n";
            return;
        }

        if(tipoComponente_ != 'a'){
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 'a' seguido do valor inteiro para o aparelho respetivo.\n";
            return;
        }
        cmd->w << "Comando valido!\n";
        cmd->w << "Para a zona "<< id_zona<< " remove associacao entre a saida do processador " << tipoComponente << valorInteiro << " com o aparelho " << tipoComponente_ << valorInteiro_ << '\n';
    }catch (invalid_argument&){
        cmd->w << "Comando invalido!Digite ades <id_zona> <id_proc.regras> <id_aparelho>\n";
    }
}

void Comando::cmd_acom(Comando *cmd) {
    if(cmd->args.size() != 4){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    string terceiroArg = cmd->args[2];
    string quartoArg = cmd->args[3];

    try{
        int id_zona = stoi(segundoArg);
        char tipoComponente = terceiroArg[0];
        int valorInteiro = stoi(terceiroArg.substr(1));
        string comando = quartoArg;

        if(tipoComponente != 'a'){
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 'a' seguido do valor inteiro para o aparelho respetivo.\n";
            return;
        }

        cmd->w << "Comando valido!\n";
        cmd->w << "Para a zona " << id_zona << " enviado manualmente o comando " << comando << " para o aparelho " << tipoComponente << valorInteiro;
    }catch (invalid_argument&){
        cmd->w << "Comando invalido!Digite acom <id_zona> <id_aparelho> <comando>\n";
    }
}

void Comando::cmd_psalva(Comando *cmd) {
    if(cmd->args.size() != 4){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    string terceiroArg = cmd->args[2];
    string quartoArg = cmd->args[3];

    try{
        int id_zona = stoi(segundoArg);
        char tipoComponente = terceiroArg[0];
        int valorInteiro = stoi(terceiroArg.substr(1));
        string nome = quartoArg;

        if(tipoComponente != 'p'){
            cmd->w << "Tipo de componente invalido: " << tipoComponente << ". Digite 'p' seguido do valor inteiro para o aparelho respetivo.\n";
            return;
        }

        cmd->w << "Comando valido!\n";
        cmd->w << "Salvo o estado do proc.regras " << tipoComponente << valorInteiro << " da zona " << id_zona << " com o nome " << nome << '\n';
    }catch (invalid_argument&){
        cmd->w << "Comando invalido!Digite psalva <id_zona> <id_proc.regras> <nome>\n";
    }
}


void Comando::cmd_prem(Comando *cmd) {
    if(cmd->args.size() != 2){
        cmd->w << "Comando invalido!\n";
        return;
    }

    string segundoArg = cmd->args[1];
    cmd->w << "Comando valido!\n";
    cmd->w << "Apaga o proc.regras que estava armazenado em memoria com o nome " << segundoArg << '\n';
}

void Comando::cmd_plista(Comando *cmd) {
    if(cmd->args.size() != 1){
        cmd->w << "Comando invalido!" << '\n';
        return;
    }

    cmd->w << "Comando valido!\n";

    //LISTA DAS COPIAS DO PROC.REGRAS
}

void Comando::cmd_exec(Comando *cmd) {
    if(cmd->args.size() !=2){
        cmd->w << "Comando invalido!\n";
        return;
    }
    string ficheiro=args[1];
    if(leFicheiro(ficheiro)){
        cmd->w << "Ficheiro lido com sucesso!\n";
    }
    else{
        cmd->w << "Erro ao abrir ficheiro!\n";
    }

}



bool Comando::leFicheiro(const string &ficheiro) {
    ifstream fich;
    string aux;
    fich.open(ficheiro);
    if (!fich) {
        return false;
    }
    while (getline(fich, aux)) {
        cout << aux << endl;
        istringstream recebe(aux);


        Comando* novoComando = new Comando(aux, w);  // Crie um novo Comando com a linha lida
        novoComando->executa();  // Execute o comando
        delete novoComando;  // Lembre-se de liberar a memória alocada
    }
    fich.close();
    return true;
}