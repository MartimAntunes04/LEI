#include "utils.h"
#include <iomanip>
#include "Terminal.h"
#include "Propriedade.h"

#include "utils.h"
#include "Sensor.h"
#include "Zona.h"
#include<vector>
#include "Comandos.h"

using namespace term;
using namespace std;

void print_size(Terminal& t) {
    std::ostringstream o;
    o << "tamanho do terminal: " << std::setw(7) << t.getNumCols() << "x" << t.getNumRows();
    std::string str = o.str();
    t.clear();
    t << set_color(0) << move_to(t.getNumCols()-str.length(), t.getNumRows()-1) << str;
}
void printZona(std::vector<Window*>& zonas, int x, int y, const std::string& mensagem) {
    int indice = x * 8 + y;

    // Verifica se o índice é válido
    if (indice >= 0 && indice < zonas.size()) {
        // Utiliza os métodos reais da classe Window
        *zonas[indice] << move_to(0, 0) << set_color(1) << mensagem;
    } else {
        std::cout << "Índice inválido!" << std::endl;
    }
}




int main() {

    Terminal &t = Terminal::instance();
    string comando;

    t.init_color(1, 2, 0);
    t.init_color(2, 4, 0);
    t << move_to(63, 12) << set_color(1) << "TRABALHO PRATICO POO 23-24";
    t << move_to(63, 16) << set_color(2) << "Trabalho Realizador por";
    t << move_to(63, 18) << set_color(0) << "Martim Antunes 2022141890";
    t << move_to(63, 19) << set_color(0) << "Pedro Faneca 2022134142";
    t << move_to(63, 21) << set_color(0) << "Carregue numa tecla para comecar";
    t.getchar();
    t.clear();

    t << move_to(73, 0) << set_color(2) << "BEM VINDO";
    t << move_to(69, 1) << set_color(1) << "Zonas de Habitacao";

    Window zona = Window(0, 0, 220, 200);

    Window zona1 = Window(1, 2, 19, 12);
    zona1 << move_to(50, 0) << set_color(1) << "1";
    Window zona2 = Window(20, 2, 19, 12);
    zona2 << move_to(50, 0) << set_color(1) << "2";
    Window zona3 = Window(39, 2, 19, 12);
    zona3 << move_to(50, 0) << set_color(1) << "3";
    Window zona4 = Window(58, 2, 19, 12);
    zona4 << move_to(50, 0) << set_color(1) << "4";
    Window zona5 = Window(77, 2, 19, 12);
    zona5 << move_to(50, 0) << set_color(1) << "5";
    Window zona6 = Window(96, 2, 19, 12);
    zona6 << move_to(50, 0) << set_color(1) << "6";
    Window zona7 = Window(115, 2, 19, 12);
    zona7 << move_to(50, 0) << set_color(1) << "7";
    Window zona8 = Window(134, 2, 19, 12);
    zona8 << move_to(50, 0) << set_color(1) << "8";
    Window zona9 = Window(1, 14, 19, 12);
    zona9 << move_to(50, 0) << set_color(1) << "9";
    Window zona10 = Window(20, 14, 19, 12);
    zona10 << move_to(50, 0) << set_color(1) << "10";
    Window zona11 = Window(39, 14, 19, 12);
    zona11 << move_to(50, 0) << set_color(1) << "11";
    Window zona12 = Window(58, 14, 19, 12);
    zona12 << move_to(50, 0) << set_color(1) << "12";
    Window zona13 = Window(77, 14, 19, 12);
    zona13 << move_to(50, 0) << set_color(1) << "13";
    Window zona14 = Window(96, 14, 19, 12);
    zona14 << move_to(50, 0) << set_color(1) << "14";
    Window zona15 = Window(115, 14, 19, 12);
    zona15 << move_to(50, 0) << set_color(1) << "15";
    Window zona16 = Window(134, 14, 19, 12);
    zona16 << move_to(50, 0) << set_color(1) << "16";



    std::vector<Window *> zonas;

    // Inicializar os ponteiros para as janelas
    zonas.push_back(&zona1);
    zonas.push_back(&zona2);
    zonas.push_back(&zona3);
    zonas.push_back(&zona4);
    zonas.push_back(&zona5);
    zonas.push_back(&zona6);
    zonas.push_back(&zona7);
    zonas.push_back(&zona8);
    zonas.push_back(&zona9);
    zonas.push_back(&zona10);
    zonas.push_back(&zona11);
    zonas.push_back(&zona12);
    zonas.push_back(&zona13);
    zonas.push_back(&zona14);
    zonas.push_back(&zona15);
    zonas.push_back(&zona16);


    Window informacoes = Window(77, 26, 76, 14);
    informacoes << set_color(1) << "INFORMACOES\n";

    Window comandos = Window(1, 26, 76, 14);
// Chamada da função para imprimir a zona desejada (substitua os valores de x e y conforme necessário)
    printZona(zonas, 1, 5, "Esta e a Zona Desejada");
    int conta_linhas_informacoes=0;
    do {

        comandos << set_color(1) << "COMANDOS\n";
        t << move_to(10, 17);

        comandos << no_color() << "Comando>";

        comandos >> comando;
        comandos.clear();
        if(comando=="sair"){
            return 0;
        }
        auto cmd= new Comando(comando,informacoes);
        informacoes << no_color();
        cmd->executa();
        conta_linhas_informacoes++;
        delete cmd;
        cmd= nullptr;

        if(conta_linhas_informacoes==8){
            informacoes.clear();
        }


    } while (1);
    t.getchar();
    t.clear();






    return 0;
}