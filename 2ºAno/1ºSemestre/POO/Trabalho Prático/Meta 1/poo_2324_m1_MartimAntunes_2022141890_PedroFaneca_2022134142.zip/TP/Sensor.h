//
// Created by ASUS on 08/11/2023.
//

#ifndef POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_SENSOR_H
#define POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_SENSOR_H
#include <vector>
#include "utils.h"
#include "Propriedade.h"
class Sensor{
    string zona,propriedade,letra;
    string tipo="s";
    int id;
    static int contador;
    vector<Propriedade>prop;

public:
    Sensor(string zona,string chave);
    int getId()const;
    string getString()const;

    double getValorPropriedade(string nomePropriedade)const;

};


#endif //POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_SENSOR_H
