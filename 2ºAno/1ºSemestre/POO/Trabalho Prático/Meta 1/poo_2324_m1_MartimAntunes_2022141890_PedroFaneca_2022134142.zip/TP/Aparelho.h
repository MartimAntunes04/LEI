//
// Created by ASUS on 14/11/2023.
//

#ifndef POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_APARELHO_H
#define POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_APARELHO_H
#include "Propriedade.h"
#include "Sensor.h"
#include "utils.h"
class Aparelho{
    string nome;
    string tipo="a";
    string letra;
    string comando;
    string efeito;
    int id;
    static int contador;

    vector<Propriedade*>propriedade;
    vector<Sensor*>sensor;

public:
    Aparelho(string letra_,string nome_,string comando_);

    string getletra()const;
    string getnome()const;
    string getString()const;
    string getComando()const;
    string getEfeito()const;
    int getId()const;
};
#endif //POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_APARELHO_H
