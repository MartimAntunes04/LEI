//
// Created by ASUS on 15/11/2023.
//

#ifndef POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_REGRA_H
#define POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_REGRA_H
#include "utils.h"
#include "Sensor.h"
class Regra{
    string descricao;
    double valorComparacao1;
    double valorComparacao2;
    string tipo="r";
    int id;
    static int contador;
    vector<Sensor*>sensor;

public:
    Regra(string descricao_,double valorComparacao1_,double valorComparacao2_);
    int getId()const;
    string getDescricao()const;
    double getvalor1()const;
    double getvalor2()const;
    string getString()const;


};

#endif //POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_REGRA_H
