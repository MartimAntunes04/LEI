//
// Created by ASUS on 14/11/2023.
//
#include "Aparelho.h"

Aparelho::Aparelho(string letra_, string nome_,string comando_) : letra(letra_),nome(nome_),comando(comando_){id=++contador;}

int Aparelho::contador=0;

string Aparelho::getletra()const{
    return letra;
}

string Aparelho::getnome()const{
    return nome;
}

string Aparelho::getComando()const{
    return comando;
}

string Aparelho::getEfeito() const {
    return efeito;
}

int Aparelho::getId() const {
    return id;
}

string Aparelho::getString() const {
    ostringstream os;
    os<<"Aparelho " << tipo << id<<"->"<<letra << "," << nome ;
    return os.str();
}