//
// Created by ASUS on 01/11/2023.
//

#ifndef POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_UTILS_H
#define POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_UTILS_H
#include <sstream>
#include <string>
#include <fstream>
#include <iostream>
#include <random>
#include <cstdlib>
#include <vector>
#include <iomanip>
#include <cctype>
using namespace std;
#endif //POO_2324_M1_MARTIMANTUNES_2022141890_PEDROFANECA_2022134142_UTILS_H
