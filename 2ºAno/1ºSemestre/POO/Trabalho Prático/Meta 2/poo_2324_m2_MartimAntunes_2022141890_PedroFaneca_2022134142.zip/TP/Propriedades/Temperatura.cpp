//
// Created by ASUS on 04/12/2023.
//

#include "Temperatura.h"

