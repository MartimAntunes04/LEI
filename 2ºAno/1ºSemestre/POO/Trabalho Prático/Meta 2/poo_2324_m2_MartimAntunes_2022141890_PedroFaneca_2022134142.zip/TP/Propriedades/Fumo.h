//
// Created by ASUS on 23/12/2023.
//

#ifndef TP_FUMO_H
#define TP_FUMO_H
#include "../Propriedade.h"

class Fumo : public Propriedade{


public:
    Fumo() : Propriedade("Fumo",15,0,100,"% Obscuracao"){}


};
#endif //TP_FUMO_H
