
struct jogador{
    char nome[50];
    pid_t pid;
    int x,y;
    int estado;
};


struct comando{
    char *nome;
    char * descricao;
    void(*func)(char *);
   
};


void verifica_comando(char*);
void mostrar_jogadores_cmd();
void comandos_cmd(char *);
void enviar_msg_cmd();
void sair_cmd();


static const struct comando comandoss[]={
    {"ajuda","Mostra a lista de comandos permitidos",&comandos_cmd},
    {"players","Lista de todos os jogadores ativos no sistema",&mostrar_jogadores_cmd},
    {"msg","Enviar mensagem a um utilizador especifico", &enviar_msg_cmd},
    {"exit","Sair",&sair_cmd},

};