#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>
#include <sys/stat.h>
#include "motor.h"
#include <ncurses.h>
#include <sys/wait.h>


#define NCOL 41
#define NLIN 16

//#define SERVER_FIFO "SERVIDOR"

char mapa[NLIN][NCOL];


void lerLabirinto() {
    FILE* arquivo = fopen("mapa1.txt", "r");
    if (arquivo == NULL) {
        perror("Erro ao abrir o arquivo");
        exit(1);
    }


    // Lê o labirinto do arquivo
    for (int i = 0; i < NLIN; i++) {
        int j = 0;
        int c;
        while ((c = fgetc(arquivo)) != EOF && c != '\n') {
            if (c == 'B') {
                mapa[i][j] = ' ';  // Substitui  'B' por espaços brancos
            } else {
                mapa[i][j] = c;
            }
            j++;
        }
        
        mapa[i][j] = '\0'; // Adiciona terminador de string
    }

    fclose(arquivo);
}

void mostraLabirinto() {
    int linhas = NLIN;
    int colunas = NCOL;

    
    // IMPRIME MUNDO
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            char avatar = mapa[i][j];
            
             if(avatar == 'B') {
                printf("");
            }
            else {
                printf("%c",avatar); 
            }
        }
        printf("\n");
    }

}



void verifica_comando(char *input) {
    if (strlen(input) == 0)
        return;

    char straux[50];
    strcpy(straux, input);

    char delim[] = " \n"; // Modificado para incluir espaço como delimitador
    char *ptr = strtok(straux, delim);
    int cmd_len = (sizeof comandoss / sizeof(struct comando));
    for(int i = 0; i < cmd_len; ++i) {
        if(strcmp(comandoss[i].nome, ptr) == 0) {
            if(strcmp(ptr,"test_bot")==0){
                comandoss[i].func(NULL);
                return;
            }
            else{
            comandoss[i].func(input);
            return;}
        }
    }
    printf("Comando desconhecido: %s\n", input);
}



    void comandos_cmd(char *x){
        printf("Lista de comandos permitidos\n");
        for(int i=0;i<(sizeof comandoss/sizeof(struct comando));i++){
            printf("%s -%s\n",comandoss[i].nome,comandoss[i].descricao);
        }
    }

    
    
    void comeca_jogo_cmd(){
        printf("Comando valido\n");
    }

     
    void encerra_jogo_cmd(){
        printf("Jogo encerrado\n");
    }

   

void remover_utilizador_cmd(char *input) {
    char delim[] = " \n";
    char *token;
    char *seguinte = NULL;

    // Divide a string em tokens usando os delimitadores
    token = strtok(input, delim);

    while (token != NULL) {
        // Se encontrarmos o comando desejado, pegamos o próximo token como a palavra desejada
        token = strtok(NULL, delim);
        if (token != NULL) {
            seguinte = token;
             printf("Comando válido. Jogador a ser removido: %s\n", seguinte);
            return;
        } else {    
            printf("Comando invalido.Digite um nome!\n");
            return;
        }
    }

}
    
void mostrar_utilizadores_cmd(){
   printf("Comando valido\n");
    if(lista_utilizadores==0){
        printf("Nenhum utilizador registado.\n");
    }
    else{
        struct utilizador * aux;
        for(aux=lista_utilizadores ;aux!=0; aux=aux->prox){
            printf("\tPID:[%d] Nome:%s",aux->pid,aux->nome);
        }
}


}



void mostrar_bots_cmd(){
     printf("Comando valido\n");
}



void insere_bloqueio_cmd(){
    printf("Comando valido\n");
}


void remover_bloqueio_cmd(){
    printf("Comando valido\n");
}




//void handle_sigalrm(int s,siginfo_t *i,void*v){

//	printf("\nAcabou o tempo- PERDERAM TODOS\n");
//	exit(1);
//}

void teste_bot(char *input) {
    int id;
    int fd[2];
    int erro = pipe(fd);
    char intervalo_str[10], duracao_str[10];
    union sigval val;

    char *token = strtok(input, " ");
    if (token == NULL) {
        printf("Formato incorreto. Formato: test_bot <intervalo> <duracao>\n");
        return;
    }

    int intervalo = atoi(token);

    token = strtok(NULL, " ");
    if (token == NULL) {
        printf("Faltam argumentos. Formato: test_bot <intervalo> <duracao>\n");
        return;
    }

    int duracao = atoi(token);

    id = fork();

    if (id == 0) {
        sprintf(intervalo_str, "%d", intervalo);
        sprintf(duracao_str, "%d", duracao);

        close(1);
        dup(fd[1]);
        close(fd[1]);
        close(fd[0]);

        execl("bot", "bot", intervalo_str, duracao_str, NULL);

        printf("Erro no execl\n");
        return;
    } else if (id > 0) {
        close(fd[1]);
        char mensagem[50];
        int i = 0;
        while (i < 10) {
            int size = read(fd[0], mensagem, sizeof(mensagem));
            if (size > 0) {
                mensagem[size] = '\0';
                printf("RECEBI: %s\n", mensagem);
            }
            i++;
        }

        sigqueue(id, SIGINT, val);
        wait(&id);
    }
}


int main(int argc,char *argv[]){
   //struct sigaction sa;
  //sa.sa_sigaction = handle_sigalrm;
	//sa.sa_flags = SA_RESTART;
	//sigaction(SIGALRM,&sa, NULL); 
     
    
   // char* inscricao_env=getenv("INSCRICAO");
    //int inscricao=atoi(inscricao_env);
   
    
   //char*duracao_env=getenv("DURACAO");
  //int temporizador=atoi(duracao_env);

   
    lerLabirinto();
    mostraLabirinto();
    
    
    char cmd[50];
    do{ 
       // alarm(temporizador);
        printf("\nComando > ");
        fgets(cmd,50,stdin);
        // Remover o caractere de nova linha
        cmd[strcspn(cmd, "\n")] = '\0';
        verifica_comando(cmd);
        if(strcmp(cmd,"end")==0)break;
           
    }while(1);
   
    

    return 0;
     }
    

    
   





   

