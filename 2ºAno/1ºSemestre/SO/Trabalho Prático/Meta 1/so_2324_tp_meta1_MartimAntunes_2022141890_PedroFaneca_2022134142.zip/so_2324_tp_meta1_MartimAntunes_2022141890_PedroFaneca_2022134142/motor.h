

#define MAXUTILIZADORES 5
#define PROCESSOSBOT 10
#define PEDRAS 50
#define NIVEIS 3
#define BLOQUEIOS 5




// ESTRUTURAS DE DADOS DO SISTEMA
struct utilizador{
    pid_t pid;
    char nome[50];
    struct utilizador *ant;
    struct utilizador *prox;
};





struct comando{
    char *nome;
    char * descricao;
    void(*func)(char *);
    int argumentos;
 
};


//  LISTAS LIGADAS
static struct utilizador * lista_utilizadores = 0;







//  FUNÇÕES DE COMANDOS
void verifica_comando(char *);
void teste_bot(char *);
void comandos_cmd(char *);
void encerra_jogo_cmd();
void mostrar_utilizadores_cmd();
void mostrar_bots_cmd();
void insere_bloqueio_cmd();
void remover_utilizador_cmd(char *);
void remover_bloqueio_cmd();
void comeca_jogo_cmd();




//Lista DE COMANDOS
static const struct comando comandoss[]={

    {"ajuda","Mostra a lista de comandos permitidos", &comandos_cmd},
    {"users","Lista os jogadores atualmente a usar a plataforma", &mostrar_utilizadores_cmd},
    {"kick", "Bane um jogador atualmente registado",  &remover_utilizador_cmd},
    {"bots","Lista os bots atualmente ativos",  &mostrar_bots_cmd},
    {"bmov","Insere bloqueio movel",  &insere_bloqueio_cmd},
    {"rbm","Elimina bloqueio movel", &remover_bloqueio_cmd},
    {"begin","Inicia jogo manualmente", &comeca_jogo_cmd},
    {"end","Encerra jogo",  &encerra_jogo_cmd},
    {"test_bot","Teste bot",&teste_bot},
    

};



