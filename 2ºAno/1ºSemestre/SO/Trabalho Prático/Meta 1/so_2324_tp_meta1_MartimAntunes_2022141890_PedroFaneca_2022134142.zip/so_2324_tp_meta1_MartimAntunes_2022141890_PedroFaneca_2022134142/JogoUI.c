#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <ncurses.h>
#include "JogoUI.h"


#define NCOL 41
#define NLIN 16

//#define SERVER_FIFO "SERVIDOR"

char mapa[NLIN][NCOL];
int posicao_linha = 0;
int posicao_coluna = 0;

void lerLabirinto() {
    FILE* arquivo = fopen("mapa1.txt", "r");
    if (arquivo == NULL) {
        perror("Erro ao abrir o arquivo");
        exit(1);
    }


    // Lê o labirinto do arquivo
    for (int i = 0; i < NLIN; i++) {
        int j = 0;
        int c;
        while ((c = fgetc(arquivo)) != EOF && c != '\n') {
            if (c == 'B') {
                mapa[i][j] = ' ';  // Substitui  'B' por espaços brancos
            } else {
                mapa[i][j] = c;
            }
            j++;
        }
        
        mapa[i][j] = '\0'; // Adiciona terminador de string
    }

    fclose(arquivo);
}

void mostraLabirinto() {
    int linhas = NLIN;
    int colunas = NCOL;

    
    // IMPRIME MUNDO
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            char avatar = mapa[i][j];
            

             if(avatar == 'B') {
                mvaddch(i, j, ' ');
            }
            else {
                mvaddch(i, j, avatar);  
            }
        }
        
    }

   refresh();
    getch(); // Aguarda o usuário pressionar uma tecla
    endwin(); // Encerra o modo ncurses
}



void desenhaMapa(WINDOW *janela, int tipo)
{

    // quando temos o scroll ativo, não deveremos ter a borda desenhada na janela para não termos o problema escrever em cima das bordas
    if (tipo == 1)
    {
        scrollok(janela, TRUE); // liga o scroll na "janela".
        wprintw(janela, "\n Comando> ");
        
    }
    else 
    {
        keypad(janela, TRUE); // para ligar as teclas de direção (aplicar à janela)
        wclear(janela);// limpa a janela
       // wborder(janela, '|', '|', '-', '-', '+', '+', '+', '+'); // Desenha uma borda. Nota importante: tudo o que escreverem, devem ter em conta a posição da borda
        

        for (int i = 0; i < NLIN; i++) {
            for (int j = 0; j < NCOL; j++) {
                char avatar = mapa[i][j];
                

                if (avatar == 'B') {
                    mvwaddch(janela, i, j, ' ');
                } else {
                    mvwaddch(janela, i, j, avatar);
                }
            }
        }
        
    }
    refresh(); // necessário para atualizar a janela
    wrefresh(janela); // necessário para atualizar a janela
}




void trataTeclado(WINDOW *janelaTopo, WINDOW *janelaBaixo) 
{
    keypad(janelaTopo, TRUE);       // para ligar as teclas de direção (aplicar à janelaTopo)
    wmove(janelaTopo, 1, 2);        // posiciona o cursor,visualmente, na posicao 1,1 da janelaTopo
    //nota a posição é relativa à janelaTopo e não ao ecrã.
    int tecla = wgetch(janelaTopo); // MUITO importante: o input é feito sobre a janela em questão, neste caso na janelaTopo
    char cmd[100];             // string que vai armazenar o comando
   
    while (tecla != 113) // trata as tecla até introduzirem a letra q. O código asci de q é 113
    {

        if (tecla == KEY_UP) // quando o utilizador introduz a seta para cima
        {
            
            desenhaMapa(janelaTopo, 2); // atualiza toda a janela
             posicao_linha = (posicao_linha - 1 + NLIN) % NLIN;
            //Nota: não escreve na posição 0,0 porque está lá a borda da janela que foi criada anteriormente
            wrefresh(janelaTopo);// // necessário para atualizar a janelaTopo. Nota: é apenas esta janela que pretendemos atualizar
             
        }
        else if (tecla == KEY_RIGHT)
        {
            desenhaMapa(janelaTopo, 2);
            posicao_coluna = (posicao_coluna + 1 + NCOL) % NCOL; 
            wrefresh(janelaTopo);
           
            
        }
        else if (tecla == KEY_LEFT)
        {
            desenhaMapa(janelaTopo, 2);
             posicao_coluna = (posicao_coluna - 1 + NCOL) % NCOL;
            wrefresh(janelaTopo);
        }
        else if (tecla == KEY_DOWN)
        {
            desenhaMapa(janelaTopo, 2);
           posicao_linha = (posicao_linha + 1 + NLIN) % NLIN;
            wrefresh(janelaTopo);
        }
        else if (tecla == ' ') // trata a tecla espaço
        {  // a tecla espaço ativa a janela inferior e tem o scroll ativo
          //  o wprintw e o wgetstr devem ser utilizados em janelas que tem o scroll ativo.
       
           
          
            echo();                         // habilita a maneira como o utilizador visualiza o que escreve
                         
            wprintw(janelaBaixo, "\n Comando> "); // utilizada para imprimir. 
             werase(janelaBaixo); // Limpar a janelaBaixo                      
            wgetstr(janelaBaixo, cmd);  // para receber do teclado uma string na "janelaBaixo" para a variavel comando

        
            verifica_comando(cmd);
        
        
           // wprintw(janelaBaixo, "\n [%s] ", cmd);
            noecho(); //voltar a desabilitar o que o utilizador escreve
            wrefresh(janelaBaixo); //sempre que se escreve numa janela, tem de se fazer refresh
           
             
        }
        
        wmove(janelaTopo, posicao_linha,posicao_coluna); // posiciona o cursor (visualmente) na posicao 1,1 da janelaTopo
        tecla = wgetch(janelaTopo); //espera que o utilizador introduza um inteiro. Importante e como já referido anteriormente introduzir a janela onde queremos receber o input
        

    }
}




void verifica_comando(char *input) {
    if (strlen(input) == 0)
        return;

    char straux[50];
    strcpy(straux, input);

    char delim[] = " \n"; // Modificado para incluir espaço como delimitador
    char *ptr = strtok(straux, delim);
int cmd_len = (sizeof comandoss / sizeof(struct comando));
    for(int i = 0; i < cmd_len; ++i) {
        if(strcmp(comandoss[i].nome, ptr) == 0) {
            comandoss[i].func(input);
            return;
        }
    }
    printf("Comando desconhecido: %s\n", input);
}


    void comandos_cmd(char *x){
        printf("Lista de comandos permitidos\n");
        for(int i=0;i<(sizeof comandoss/sizeof(struct comando));i++){
            printf("%s -%s\n",comandoss[i].nome,comandoss[i].descricao);
        }

    }

    


    void mostrar_jogadores_cmd(){
       printf("Comando valido\n");
    }

   


    void enviar_msg_cmd(char *input){
        char delim[] = " \n";
    char *ptr = strtok(input, delim);

    if (ptr == NULL) {
        printf("Utilize o seguinte formato para o comando: msg <nome_utilizador> <mensagem>\n");
        return;
    }

    char *nomeUsuario = strtok(NULL, delim);

    if (nomeUsuario == NULL) {
        printf("Nome de usuário ausente. Utilize o seguinte formato para o comando: msg <nome_utilizador> <mensagem>\n");
        return;
    }

    char *mensagem = strtok(NULL, "");  // Usamos NULL para continuar a partir da última posição

    if (mensagem == NULL) {
        printf("Mensagem ausente. Utilize o seguinte formato para o comando: msg <nome_utilizador> <mensagem>\n");
        return;
    }

    // Agora temos nome do usuário em 'nomeUsuario' e a mensagem em 'mensagem'
    
    // Aqui você pode adicionar lógica para enviar a mensagem ao usuário específico
    printf("Enviar mensagem para '%s': '%s'\n", nomeUsuario, mensagem);

    }

    

    void sair_cmd(){
         printf("Sair do jogo...\n");
        exit(1); 
    }

    
    
    
    
    
    

    int main(int argc, char*argv[]){
    
    if(argc!=2){
        printf("Erro do numero de argumentos\n");
        return -1;
    }

    char *nome=argv[1];
    
    


    initscr();
    raw();
    noecho();
    keypad(stdscr, TRUE);
    attrset(A_DIM);
    //mvprintw(1, 10, "[ Up,Down,Right e Left comandos janela de cima ]");
    //mvprintw(2, 10, "[ space - muda para o foco da janela de baixo / q - sair ]");
    WINDOW *janelaTopo = newwin(NLIN + 1, NCOL + 2, 3, 1);
    WINDOW *janelaBaixo = newwin(15, 82, 26, 1);
    
    lerLabirinto();
    desenhaMapa(janelaTopo, 2);
    desenhaMapa(janelaBaixo, 1);
    trataTeclado(janelaTopo, janelaBaixo);

    endwin();

return 0;
}